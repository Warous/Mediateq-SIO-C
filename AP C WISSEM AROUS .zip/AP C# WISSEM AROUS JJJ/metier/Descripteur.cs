﻿using System.Collections.Generic;
using Mediateq_AP_SIO2.modele;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un descripteur.
    /// </summary>
    class Descripteur
    {
        /// <summary>
        /// Obtient ou définit l'identifiant du descripteur.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Obtient ou définit le libellé du descripteur.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Descripteur"/>.
        /// </summary>
        /// <param name="id">L'identifiant du descripteur.</param>
        /// <param name="libelle">Le libellé du descripteur.</param>
        public Descripteur(int id, string libelle)
        {
            Id = id;
            Libelle = libelle;
        }

        /// <summary>
        /// Récupère tous les descripteurs.
        /// </summary>
        /// <returns>Une liste de tous les descripteurs.</returns>
        public static List<Descripteur> GetAll()
        {
            return DAODescripteur.GetAll();
        }

        /// <summary>
        /// Récupère un descripteur par son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant du descripteur à récupérer.</param>
        /// <returns>Le descripteur trouvé, ou null s'il n'existe pas.</returns>
        public static Descripteur Get(int id)
        {
            return DAODescripteur.Get(id);
        }
    }
}
