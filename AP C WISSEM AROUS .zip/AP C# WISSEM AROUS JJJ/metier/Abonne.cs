﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mediateq_AP_SIO2.modele;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un abonné.
    /// </summary>
    internal class Abonne
    {
        /// <summary>
        /// Obtient ou définit le numéro d'abonnement de l'abonné.
        /// </summary>
        public int Numero_abonnement { get; set; }

        /// <summary>
        /// Obtient ou définit le nom de l'abonné.
        /// </summary>
        public string Nom { get; set; }

        /// <summary>
        /// Obtient ou définit le prénom de l'abonné.
        /// </summary>
        public string Prenom { get; set; }

        /// <summary>
        /// Obtient ou définit le mot de passe de l'abonné.
        /// </summary>
        public string Mdp { get; set; }

        /// <summary>
        /// Obtient ou définit la date de fin d'abonnement de l'abonné.
        /// </summary>
        public DateTime Date_fin_abonnement { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Abonne"/>.
        /// </summary>
        /// <param name="numero_abonnement">Le numéro d'abonnement de l'abonné.</param>
        /// <param name="nom">Le nom de l'abonné.</param>
        /// <param name="prenom">Le prénom de l'abonné.</param>
        /// <param name="mdp">Le mot de passe de l'abonné.</param>
        /// <param name="date_fin_abonnement">La date de fin d'abonnement de l'abonné.</param>
        public Abonne(int numero_abonnement, string nom, string prenom, string mdp, DateTime date_fin_abonnement)
        {
            Numero_abonnement = numero_abonnement;
            Nom = nom;
            Prenom = prenom;
            Mdp = mdp;
            Date_fin_abonnement = date_fin_abonnement;
        }

        /// <summary>
        /// Récupère un abonné par son nom.
        /// </summary>
        /// <param name="nom">Le nom de l'abonné à récupérer.</param>
        /// <returns>L'abonné trouvé, ou null s'il n'existe pas.</returns>
        public static Abonne Get(string nom)
        {
            return DAOAbonne.Get(nom);
        }

        /// <summary>
        /// Récupère tous les abonnés.
        /// </summary>
        /// <returns>Une liste de tous les abonnés.</returns>
        public static List<Abonne> GetAll()
        {
            return DAOAbonne.GetAll();
        }

        /// <summary>
        /// Récupère tous les signalements associés aux abonnés.
        /// </summary>
        /// <returns>Une liste de tous les signalements associés aux abonnés.</returns>
        public static List<Signalement> GetAllSignalement()
        {
            return DAOAbonne.GetAllSignalement();
        }
    }
}
