﻿using Mediateq_AP_SIO2.modele;
using System.Collections.Generic;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un DVD, une sous-classe de Document.
    /// </summary>
    class Dvd : Document
    {
        /// <summary>
        /// Obtient ou définit le synopsis du DVD.
        /// </summary>
        public string Synopsis { get; set; }

        /// <summary>
        /// Obtient ou définit le réalisateur du DVD.
        /// </summary>
        public string Realisateur { get; set; }

        /// <summary>
        /// Obtient ou définit la durée du DVD en minutes.
        /// </summary>
        public int Duree { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Dvd"/>.
        /// </summary>
        /// <param name="id">L'identifiant du DVD.</param>
        /// <param name="titre">Le titre du DVD.</param>
        /// <param name="synopsis">Le synopsis du DVD.</param>
        /// <param name="realisateur">Le réalisateur du DVD.</param>
        /// <param name="duree">La durée du DVD en minutes.</param>
        /// <param name="image">Le chemin de l'image associée au DVD.</param>
        /// <param name="commandeencours">Le nombre de commandes en cours pour ce DVD.</param>
        /// <param name="publiccible">Le public cible du DVD.</param>
        /// <param name="existe">Indique si le DVD existe.</param>
        public Dvd(int id, string titre, string synopsis, string realisateur, int duree, string image, int commandeencours, PublicCible publiccible, bool existe) : base(id, titre, image, commandeencours, publiccible, existe)
        {
            Synopsis = synopsis;
            Realisateur = realisateur;
            Duree = duree;
        }

        /// <summary>
        /// Récupère tous les DVD.
        /// </summary>
        /// <returns>Une liste de tous les DVD.</returns>
        public static List<Dvd> GetAll()
        {
            return DAODvd.GetAll();
        }

        /// <summary>
        /// Récupère un DVD par son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant du DVD à récupérer.</param>
        /// <returns>Le DVD trouvé, ou null s'il n'existe pas.</returns>
        public static Dvd Get(int id)
        {
            return DAODvd.Get(id);
        }

        /// <summary>
        /// Crée un nouveau DVD.
        /// </summary>
        /// <param name="id">L'identifiant du DVD.</param>
        /// <param name="titre">Le titre du DVD.</param>
        /// <param name="synopsis">Le synopsis du DVD.</param>
        /// <param name="realisateur">Le réalisateur du DVD.</param>
        /// <param name="duree">La durée du DVD en minutes.</param>
        /// <param name="image">Le chemin de l'image associée au DVD.</param>
        /// <param name="commandeencours">Le nombre de commandes en cours pour ce DVD.</param>
        /// <param name="publiccible">Le public cible du DVD.</param>
        public static void CreateDvd(int id, string titre, string synopsis, string realisateur, int duree, string image, int commandeencours, int publiccible)
        {
            DAODvd.CreateDvd(id, titre, synopsis, realisateur, duree, image, commandeencours, publiccible);
        }

        /// <summary>
        /// Met à jour un DVD existant.
        /// </summary>
        /// <param name="document">Le DVD à mettre à jour.</param>
        /// <param name="synopsis">Le nouveau synopsis du DVD.</param>
        /// <param name="realisateur">Le nouveau réalisateur du DVD.</param>
        /// <param name="duree">La nouvelle durée du DVD en minutes.</param>
        public static void UpdateDvd(Document document, string synopsis, string realisateur, int duree)
        {
            DAODvd.UpdateDvd(document, synopsis, realisateur, duree);
        }

        /// <summary>
        /// Supprime un DVD existant.
        /// </summary>
        /// <param name="document">Le DVD à supprimer.</param>
        public static void DeleteDvd(Document document)
        {
            DAODvd.DeleteDvd(document);
        }
    }
}
