﻿using System;
using System.Collections.Generic;
using Mediateq_AP_SIO2.modele;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente une revue dans le système.
    /// </summary>
    public class Revue
    {
        /// <summary>
        /// Obtient ou définit l'identifiant de la revue.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Obtient ou définit le titre de la revue.
        /// </summary>
        public string Titre { get; set; }

        /// <summary>
        /// Obtient ou définit la disponibilité de la revue pour l'emprunt.
        /// </summary>
        public string Empruntable { get; set; }

        /// <summary>
        /// Obtient ou définit la périodicité de la revue.
        /// </summary>
        public string Periodicite { get; set; }

        /// <summary>
        /// Obtient ou définit la date de fin d'abonnement de la revue.
        /// </summary>
        public DateTime DateFinAbonnement { get; set; }

        /// <summary>
        /// Obtient ou définit le délai de mise à disposition de la revue.
        /// </summary>
        public int DelaiMiseADispo { get; set; }

        /// <summary>
        /// Obtient ou définit le descripteur de la revue.
        /// </summary>
        internal Descripteur IdDescripteur { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe Revue.
        /// </summary>
        /// <param name="id">L'identifiant de la revue.</param>
        /// <param name="titre">Le titre de la revue.</param>
        /// <param name="empruntable">La disponibilité de la revue pour l'emprunt.</param>
        /// <param name="periodicite">La périodicité de la revue.</param>
        /// <param name="dateFinAbonnement">La date de fin d'abonnement de la revue.</param>
        /// <param name="delaiMiseADispo">Le délai de mise à disposition de la revue.</param>
        /// <param name="idDescripteur">Le descripteur de la revue.</param>
        internal Revue(int id, string titre, string empruntable, string periodicite, DateTime dateFinAbonnement, int delaiMiseADispo, Descripteur idDescripteur)
        {
            Id = id;
            Titre = titre;
            Empruntable = empruntable;
            Periodicite = periodicite;
            DateFinAbonnement = dateFinAbonnement;
            DelaiMiseADispo = delaiMiseADispo;
            IdDescripteur = idDescripteur;
        }

        /// <summary>
        /// Récupère toutes les revues du système.
        /// </summary>
        /// <returns>Une liste de toutes les revues du système.</returns>
        public static List<Revue> GetAll()
        {
            return DAORevue.GetAll();
        }

        /// <summary>
        /// Récupère une revue en fonction de son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant de la revue à récupérer.</param>
        /// <returns>La revue correspondant à l'identifiant spécifié.</returns>
        public static Revue Get(int id)
        {
            return DAORevue.Get(id);
        }
    }
}
