﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Classe utilitaire pour la génération de sel et le hachage de mots de passe.
    /// </summary>
    public class Hash
    {
        /// <summary>
        /// Génère un sel aléatoire pour sécuriser les mots de passe.
        /// </summary>
        /// <param name="length">Longueur du sel en octets.</param>
        /// <returns>Le sel généré sous forme de chaîne encodée en base64.</returns>
        public static string GenerateSalt(int length = 16)
        {
            byte[] salt = new byte[length];
            using (var rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(salt);
            }
            return Convert.ToBase64String(salt);
        }

        /// <summary>
        /// Hache un mot de passe en utilisant un sel spécifié.
        /// </summary>
        /// <param name="password">Le mot de passe à hacher.</param>
        /// <param name="salt">Le sel à utiliser pour le hachage.</param>
        /// <returns>Le mot de passe haché sous forme de chaîne encodée en base64.</returns>
        public static string HashPassword(string password, string salt)
        {
            byte[] saltBytes = Convert.FromBase64String(salt);

            using (var sha256 = new SHA256Managed())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] saltedPassword = new byte[passwordBytes.Length + saltBytes.Length];
                Buffer.BlockCopy(passwordBytes, 0, saltedPassword, 0, passwordBytes.Length);
                Buffer.BlockCopy(saltBytes, 0, saltedPassword, passwordBytes.Length, saltBytes.Length);

                byte[] hash = sha256.ComputeHash(saltedPassword);

                return Convert.ToBase64String(hash);
            }
        }
    }
}
