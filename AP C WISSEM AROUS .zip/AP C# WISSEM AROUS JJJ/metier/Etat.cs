﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Mediateq_AP_SIO2.modele;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente l'état d'un élément.
    /// </summary>
    public class Etat
    {
        /// <summary>
        /// Obtient ou définit l'identifiant de l'état.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Obtient ou définit le libellé de l'état.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Etat"/>.
        /// </summary>
        /// <param name="id">L'identifiant de l'état.</param>
        /// <param name="libelle">Le libellé de l'état.</param>
        public Etat(int id, string libelle)
        {
            Id = id;
            Libelle = libelle;
        }

        /// <summary>
        /// Récupère l'état par son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant de l'état à récupérer.</param>
        /// <returns>L'état trouvé, ou null s'il n'existe pas.</returns>
        public static Etat Get(int id)
        {
            return DAOEtat.Get(id);
        }

        /// <summary>
        /// Récupère tous les états.
        /// </summary>
        /// <returns>Une liste de tous les états.</returns>
        public static List<Etat> GetAll()
        {
            return DAOEtat.GetAll();
        }
    }
}
