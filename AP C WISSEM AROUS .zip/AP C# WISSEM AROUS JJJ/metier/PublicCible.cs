﻿using Mediateq_AP_SIO2.modele;
using System;
using System.Collections.Generic;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un public cible dans le système.
    /// </summary>
    public class PublicCible
    {
        /// <summary>
        /// Obtient ou définit l'identifiant du public cible.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Obtient ou définit le libellé du public cible.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe PublicCible.
        /// </summary>
        /// <param name="id">L'identifiant du public cible.</param>
        /// <param name="libelle">Le libellé du public cible.</param>
        public PublicCible(int id, string libelle)
        {
            Id = id;
            Libelle = libelle;
        }

        /// <summary>
        /// Récupère un objet PublicCible en fonction de son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant du public cible à récupérer.</param>
        /// <returns>L'objet PublicCible correspondant à l'identifiant spécifié.</returns>
        public static PublicCible Get(int id)
        {
            return DAOPublicCible.Get(id);
        }

        /// <summary>
        /// Récupère un objet PublicCible en fonction de son libellé.
        /// </summary>
        /// <param name="libelle">Le libellé du public cible à récupérer.</param>
        /// <returns>L'objet PublicCible correspondant au libellé spécifié.</returns>
        public static PublicCible Get(string libelle)
        {
            return DAOPublicCible.Get(libelle);
        }

        /// <summary>
        /// Récupère tous les objets PublicCible disponibles dans le système.
        /// </summary>
        /// <returns>Une liste contenant tous les objets PublicCible.</returns>
        public static List<PublicCible> GetAll()
        {
            return DAOPublicCible.GetAll();
        }
    }
}
