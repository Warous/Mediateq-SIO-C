﻿using Mediateq_AP_SIO2.modele;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un signalement effectué par un abonné concernant un exemplaire de document.
    /// </summary>
    public class Signalement
    {
        /// <summary>
        /// Obtient ou définit le document associé au signalement.
        /// </summary>
        internal Document Document { get; set; }

        /// <summary>
        /// Obtient ou définit l'exemplaire concerné par le signalement.
        /// </summary>
        internal Exemplaire Exemplaire { get; set; }

        /// <summary>
        /// Obtient ou définit l'état du document signalé.
        /// </summary>
        public Etat Etat { get; set; }

        /// <summary>
        /// Obtient ou définit l'abonné qui a effectué le signalement.
        /// </summary>
        internal Abonne Abonne { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe Signalement avec les paramètres spécifiés.
        /// </summary>
        /// <param name="document">Le document associé au signalement.</param>
        /// <param name="exemplaire">L'exemplaire concerné par le signalement.</param>
        /// <param name="etat">L'état du document signalé.</param>
        /// <param name="abonne">L'abonné qui a effectué le signalement.</param>
        internal Signalement(Document document, Exemplaire exemplaire, Etat etat, Abonne abonne)
        {
            Document = document;
            Exemplaire = exemplaire;
            Etat = etat;
            Abonne = abonne;
        }
    }
}
