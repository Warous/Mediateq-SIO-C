﻿using System.Collections.Generic;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un document.
    /// </summary>
    class Document
    {
        /// <summary>
        /// Obtient ou définit l'identifiant du document.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Obtient ou définit le titre du document.
        /// </summary>
        public string Titre { get; set; }

        /// <summary>
        /// Obtient ou définit le chemin de l'image associée au document.
        /// </summary>
        public string Image { get; set; }

        /// <summary>
        /// Obtient ou définit le nombre de commandes en cours pour ce document.
        /// </summary>
        public int CommandeEnCours { get; set; }

        /// <summary>
        /// Obtient ou définit le public cible du document.
        /// </summary>
        public PublicCible PublicCible { get; set; }

        /// <summary>
        /// Indique si le document existe.
        /// </summary>
        public bool Existe { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Document"/>.
        /// </summary>
        /// <param name="id">L'identifiant du document.</param>
        /// <param name="titre">Le titre du document.</param>
        /// <param name="image">Le chemin de l'image associée au document.</param>
        /// <param name="commandeencours">Le nombre de commandes en cours pour ce document.</param>
        /// <param name="publiccible">Le public cible du document.</param>
        /// <param name="existe">Indique si le document existe.</param>
        public Document(int id, string titre, string image, int commandeencours, PublicCible publiccible, bool existe)
        {
            Id = id;
            Titre = titre;
            Image = image;
            CommandeEnCours = commandeencours;
            PublicCible = publiccible;
            Existe = existe;
        }

        /// <summary>
        /// Récupère un document par son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant du document à récupérer.</param>
        /// <returns>Le document trouvé, ou null s'il n'existe pas.</returns>
        public static Document Get(int id)
        {
            return DAODocuments.Get(id);
        }

        /// <summary>
        /// Récupère tous les documents.
        /// </summary>
        /// <returns>Une liste de tous les documents.</returns>
        public static List<Document> GetAll()
        {
            return DAODocuments.GetAll();
        }
    }
}
