﻿using System;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente une parution d'une revue dans le système.
    /// </summary>
    class Parution
    {
        /// <summary>
        /// Obtient ou définit le numéro de la parution.
        /// </summary>
        public int Numero { get; set; }

        /// <summary>
        /// Obtient ou définit la date de parution de la revue.
        /// </summary>
        public DateTime DateParution { get; set; }

        /// <summary>
        /// Obtient ou définit le chemin de la photo associée à la parution.
        /// </summary>
        public string Photo { get; set; }

        /// <summary>
        /// Obtient ou définit l'identifiant de la revue associée à la parution.
        /// </summary>
        public string IdRevue { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe Parution.
        /// </summary>
        /// <param name="numero">Le numéro de la parution.</param>
        /// <param name="dateParution">La date de parution de la revue.</param>
        /// <param name="photo">Le chemin de la photo associée à la parution.</param>
        /// <param name="idRevue">L'identifiant de la revue associée à la parution.</param>
        public Parution(int numero, DateTime dateParution, string photo, string idRevue)
        {
            this.Numero = numero;
            this.DateParution = dateParution;
            this.Photo = photo;
            this.IdRevue = idRevue;
        }
    }
}
