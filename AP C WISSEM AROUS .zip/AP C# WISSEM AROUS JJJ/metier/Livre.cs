﻿using System.Collections.Generic;
using Mediateq_AP_SIO2.modele;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un livre dans le système.
    /// </summary>
    class Livre : Document
    {
        /// <summary>
        /// Obtient ou définit l'ISBN du livre.
        /// </summary>
        public string ISBN { get; set; }

        /// <summary>
        /// Obtient ou définit l'auteur du livre.
        /// </summary>
        public string Auteur { get; set; }

        /// <summary>
        /// Obtient ou définit la collection à laquelle appartient le livre.
        /// </summary>
        public string Collection { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe Livre.
        /// </summary>
        /// <param name="id">L'identifiant du livre.</param>
        /// <param name="titre">Le titre du livre.</param>
        /// <param name="ISBN">L'ISBN du livre.</param>
        /// <param name="auteur">L'auteur du livre.</param>
        /// <param name="collection">La collection du livre.</param>
        /// <param name="image">Le chemin de l'image associée au livre.</param>
        /// <param name="commandeencours">Le nombre de commandes en cours pour le livre.</param>
        /// <param name="publiccible">Le public cible du livre.</param>
        /// <param name="existe">Indique si le livre existe dans le système.</param>
        public Livre(int id, string titre, string ISBN, string auteur, string collection, string image, int commandeencours, PublicCible publiccible, bool existe)
            : base(id, titre, image, commandeencours, publiccible, existe)
        {
            this.ISBN = ISBN;
            this.Auteur = auteur;
            this.Collection = collection;
        }

        /// <summary>
        /// Récupère tous les livres du système.
        /// </summary>
        /// <returns>Une liste contenant tous les livres.</returns>
        public static List<Livre> GetAll()
        {
            return DAOLivre.GetAll();
        }

        /// <summary>
        /// Récupère un livre à partir de son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant du livre à récupérer.</param>
        /// <returns>Le livre correspondant à l'identifiant spécifié.</returns>
        public static Livre Get(int id)
        {
            return DAOLivre.Get(id);
        }

        /// <summary>
        /// Crée un nouveau livre dans le système.
        /// </summary>
        /// <param name="id">L'identifiant du livre.</param>
        /// <param name="titre">Le titre du livre.</param>
        /// <param name="ISBN">L'ISBN du livre.</param>
        /// <param name="auteur">L'auteur du livre.</param>
        /// <param name="collection">La collection du livre.</param>
        /// <param name="image">Le chemin de l'image associée au livre.</param>
        /// <param name="commandeencours">Le nombre de commandes en cours pour le livre.</param>
        /// <param name="publiccible">Le public cible du livre.</param>
        public static void CreateLivre(int id, string titre, string ISBN, string auteur, string collection, string image, int commandeencours, int publiccible)
        {
            DAOLivre.CreateLivre(id, titre, ISBN, auteur, collection, image, commandeencours, publiccible);
        }

        /// <summary>
        /// Met à jour les informations d'un livre existant dans le système.
        /// </summary>
        /// <param name="document">Le document représentant le livre à mettre à jour.</param>
        /// <param name="ISBN">Le nouvel ISBN du livre.</param>
        /// <param name="auteur">Le nouvel auteur du livre.</param>
        /// <param name="collection">La nouvelle collection du livre.</param>
        public static void UpdateLivre(Document document, string ISBN, string auteur, string collection)
        {
            DAOLivre.UpdateLivre(document, ISBN, auteur, collection);
        }

        /// <summary>
        /// Supprime un livre du système.
        /// </summary>
        /// <param name="document">Le document représentant le livre à supprimer.</param>
        public static void DeleteLivre(Document document)
        {
            DAOLivre.DeleteLivre(document);
        }
    }
}
