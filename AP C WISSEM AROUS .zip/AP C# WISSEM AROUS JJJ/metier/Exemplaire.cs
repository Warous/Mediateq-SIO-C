﻿using System;
using System.Collections.Generic;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un exemplaire d'un document dans la médiathèque.
    /// </summary>
    class Exemplaire
    {
        /// <summary>
        /// Obtient ou définit le document associé à l'exemplaire.
        /// </summary>
        public Document Document { get; set; }

        /// <summary>
        /// Obtient ou définit le numéro de l'exemplaire.
        /// </summary>
        public int Numero { get; set; }

        /// <summary>
        /// Obtient ou définit la date d'achat de l'exemplaire.
        /// </summary>
        public DateTime DateAchat { get; set; }

        /// <summary>
        /// Obtient ou définit l'état de l'exemplaire.
        /// </summary>
        public Etat Etat { get; set; }

        /// <summary>
        /// Obtient ou définit le rayon où est placé l'exemplaire.
        /// </summary>
        public Rayon Rayon { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Exemplaire"/>.
        /// </summary>
        /// <param name="document">Le document associé à l'exemplaire.</param>
        /// <param name="numero">Le numéro de l'exemplaire.</param>
        /// <param name="date">La date d'achat de l'exemplaire.</param>
        /// <param name="rayon">Le rayon où est placé l'exemplaire.</param>
        /// <param name="etat">L'état de l'exemplaire.</param>
        public Exemplaire(Document document, int numero, DateTime date, Rayon rayon, Etat etat)
        {
            Document = document;
            Numero = numero;
            DateAchat = date;
            Rayon = rayon;
            Etat = etat;
        }

        /// <summary>
        /// Récupère tous les exemplaires d'un document spécifié.
        /// </summary>
        /// <param name="document">Le document pour lequel récupérer les exemplaires.</param>
        /// <returns>Une liste d'exemplaires du document spécifié.</returns>
        public static List<Exemplaire> GetAllByDocument(Document document)
        {
            return DAOExemplaire.GetAllByDocument(document);
        }

        /// <summary>
        /// Récupère un exemplaire spécifié par son document et son numéro.
        /// </summary>
        /// <param name="id">Le document associé à l'exemplaire.</param>
        /// <param name="numero">Le numéro de l'exemplaire.</param>
        /// <returns>L'exemplaire trouvé, ou null s'il n'existe pas.</returns>
        public static Exemplaire Get(Document id, int numero)
        {
            return DAOExemplaire.Get(id, numero);
        }

        /// <summary>
        /// Récupère tous les exemplaires.
        /// </summary>
        /// <returns>Une liste de tous les exemplaires.</returns>
        public static List<Exemplaire> GetAll()
        {
            return DAOExemplaire.GetAll();
        }

        /// <summary>
        /// Récupère tous les exemplaires selon l'état spécifié.
        /// </summary>
        /// <param name="idEtat">L'identifiant de l'état des exemplaires à récupérer.</param>
        /// <returns>Une liste d'exemplaires avec l'état spécifié.</returns>
        public static List<Exemplaire> GetAllByEtat(int idEtat)
        {
            return DAOExemplaire.GetAllByEtat(idEtat);
        }

        /// <summary>
        /// Insère un signalement pour un exemplaire donné.
        /// </summary>
        /// <param name="document">Le document associé à l'exemplaire.</param>
        /// <param name="exemplaire">L'exemplaire pour lequel insérer le signalement.</param>
        /// <param name="id">L'identifiant du signalement à insérer.</param>
        /// <param name="abonne">L'abonné qui signale l'exemplaire.</param>
        public static void InsertSignalement(Document document, Exemplaire exemplaire, int id, Abonne abonne)
        {
            DAOExemplaire.InsertSignalement(document, exemplaire, id, abonne);
        }

        /// <summary>
        /// Met à jour les informations d'un exemplaire spécifié.
        /// </summary>
        /// <param name="document">Le document associé à l'exemplaire.</param>
        /// <param name="exemplaire">L'exemplaire à mettre à jour.</param>
        /// <param name="id">L'identifiant de l'exemplaire à mettre à jour.</param>
        public static void UpdateExemplaire(Document document, Exemplaire exemplaire, int id)
        {
            DAOExemplaire.UpdateExemplaire(document, exemplaire, id);
        }

        /// <summary>
        /// Met à jour l'état d'un exemplaire spécifié.
        /// </summary>
        /// <param name="etat">Le nouvel état de l'exemplaire.</param>
        /// <param name="document">Le document associé à l'exemplaire.</param>
        /// <param name="exemplaire">L'exemplaire à mettre à jour.</param>
        public static void UpdateEtat(Etat etat, Document document, Exemplaire exemplaire)
        {
            DAOExemplaire.UpdateEtat(etat, document, exemplaire);
        }
    }
}
