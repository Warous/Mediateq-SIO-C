﻿using Mediateq_AP_SIO2.modele;
using System;
using System.Collections.Generic;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un rayon dans le système.
    /// </summary>
    public class Rayon
    {
        /// <summary>
        /// Obtient ou définit l'identifiant du rayon.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Obtient ou définit le libellé du rayon.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe Rayon.
        /// </summary>
        /// <param name="unid">L'identifiant du rayon.</param>
        /// <param name="unlibelle">Le libellé du rayon.</param>
        public Rayon(int unid, string unlibelle)
        {
            Id = unid;
            Libelle = unlibelle;
        }

        /// <summary>
        /// Récupère un objet Rayon en fonction de son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant du rayon à récupérer.</param>
        /// <returns>L'objet Rayon correspondant à l'identifiant spécifié.</returns>
        public static Rayon Get(int id)
        {
            return DAORayon.Get(id);
        }
    }
}
