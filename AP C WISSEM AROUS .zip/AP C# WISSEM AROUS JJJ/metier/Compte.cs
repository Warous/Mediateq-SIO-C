﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mediateq_AP_SIO2.modele;

namespace Mediateq_AP_SIO2.metier
{
    /// <summary>
    /// Représente un compte utilisateur.
    /// </summary>
    internal class Compte
    {
        /// <summary>
        /// Obtient ou définit le nom de famille du titulaire du compte.
        /// </summary>
        public string Nom { get; set; }

        /// <summary>
        /// Obtient ou définit le prénom du titulaire du compte.
        /// </summary>
        public string Prenom { get; set; }

        /// <summary>
        /// Obtient ou définit l'identifiant du compte.
        /// </summary>
        public string Identifiant { get; set; }

        /// <summary>
        /// Obtient ou définit le mot de passe du compte.
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Obtient ou définit le service associé au compte.
        /// </summary>
        public string Service { get; set; }

        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Compte"/>.
        /// </summary>
        /// <param name="nom">Le nom de famille du titulaire du compte.</param>
        /// <param name="prenom">Le prénom du titulaire du compte.</param>
        /// <param name="identifiant">L'identifiant du compte.</param>
        /// <param name="password">Le mot de passe du compte.</param>
        /// <param name="service">Le service associé au compte.</param>
        public Compte(string nom, string prenom, string identifiant, string password, string service)
        {
            Nom = nom;
            Prenom = prenom;
            Identifiant = identifiant;
            Password = password;
            Service = service;
        }

        /// <summary>
        /// Récupère tous les comptes utilisateur.
        /// </summary>
        /// <returns>Une liste de tous les comptes utilisateur.</returns>
        public static List<Compte> GetAll()
        {
            return DAOCompte.GetAll();
        }
    }
}
