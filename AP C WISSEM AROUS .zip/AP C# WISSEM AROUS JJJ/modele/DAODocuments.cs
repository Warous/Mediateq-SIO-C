﻿using Mediateq_AP_SIO2.metier;
using Mediateq_AP_SIO2.modele;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace Mediateq_AP_SIO2
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec la table document dans la base de données.
    /// </summary>
    class DAODocuments
    {
        /// <summary>
        /// Obtient la catégorie d'un livre à partir de la base de données.
        /// </summary>
        /// <param name="pLivre">Le livre pour lequel récupérer la catégorie.</param>
        /// <returns>La catégorie du livre.</returns>
        public static PublicCible getCategorieByLivre(Livre pLivre)
        {
            PublicCible categorie;
            string req = "Select p.id,p.libelle from public p,document d where p.id = d.idPublic and d.id='";
            req += pLivre.Id + "'";

            DaoFactory.connecter();

            MySqlDataReader reader = DaoFactory.execSQLRead(req);

            if (reader.Read())
            {
                categorie = new PublicCible(Convert.ToInt32(reader[0].ToString()), reader[1].ToString());
            }
            else
            {
                categorie = null;
            }
            DaoFactory.deconnecter();
            return categorie;
        }

        /// <summary>
        /// Récupère un document spécifique par son ID depuis la base de données.
        /// </summary>
        /// <param name="id">L'ID du document à récupérer.</param>
        /// <returns>Le document correspondant à l'ID spécifié.</returns>
        public static Document Get(int id)
        {
            string req = $"SELECT * FROM document WHERE id = {id}";
            List<string> listRawDocument = new List<string>();
            listRawDocument = ManageBase.GetOne(req, 6);
            int idDocument = Convert.ToInt32(listRawDocument[0]);
            string titre = listRawDocument[1].ToString();
            string image = listRawDocument[2].ToString();
            int commandeEnCours;
            if (listRawDocument[3] != "")
            {
                commandeEnCours = Convert.ToInt32(listRawDocument[4]);
            }
            else
            {
                commandeEnCours = 0;
            }
            int idPublic = Convert.ToInt32(listRawDocument[4]);
            PublicCible publicCible = PublicCible.Get(idPublic);
            bool existe = Convert.ToBoolean(listRawDocument[5]);
            Document document = new Document(idDocument, titre, image, commandeEnCours, publicCible, existe);
            document.CommandeEnCours = commandeEnCours;
            return document;
        }

        /// <summary>
        /// Récupère tous les documents depuis la base de données.
        /// </summary>
        /// <returns>Une liste de documents.</returns>
        public static List<Document> GetAll()
        {
            List<Document> listDocuments = new List<Document>();

            string req = $"SELECT * FROM document WHERE existe = 0";

            List<List<string>> listRawDocument = ManageBase.GetList(req, 6);

            foreach (List<string> rawDocument in listRawDocument)
            {
                int idDocument = Convert.ToInt32(rawDocument[0]);
                string titre = rawDocument[1];
                string image = rawDocument[2];
                int commandeEnCours;
                if (rawDocument[3] != "")
                {
                    commandeEnCours = Convert.ToInt32(rawDocument[4]);
                }
                else
                {
                    commandeEnCours = 0;
                }
                int idPublic = Convert.ToInt32(rawDocument[4]);
                PublicCible publicCible = PublicCible.Get(idPublic);
                bool existe = Convert.ToBoolean(rawDocument[5]);
                Document document = new Document(idDocument, titre, image, commandeEnCours, publicCible, existe);
                listDocuments.Add(document);
            }

            return listDocuments;
        }
    }
}
