﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Mediateq_AP_SIO2.metier;

namespace Mediateq_AP_SIO2
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec les données de presse dans la base de données.
    /// </summary>
    class DAOPresse
    {
        /*
        public static List<Domaine> getAllDomaines()
        {
            List<Domaine> lesDomaines = new List<Domaine>();
            string req = "Select * from domaine";

            DAOFactory.connecter();

            MySqlDataReader reader = DAOFactory.execSQLRead(req);

            while (reader.Read())
            {
                Domaine domaine = new Domaine(reader[0].ToString(), reader[1].ToString());
                lesDomaines.Add(domaine);
            }
            DAOFactory.deconnecter();
            return lesDomaines;
        }

        public static Domaine getDomainesById(string pId)
        {
            Domaine domaine;
            string req = "Select * from domaine where idDomaine = " + pId;

            DAOFactory.connecter();

            MySqlDataReader reader = DAOFactory.execSQLRead(req);

            if (reader.Read())
            {
                domaine = new Domaine(reader[0].ToString(), reader[1].ToString());
            }
            else
            {
                domaine =null;
            }
            DAOFactory.deconnecter();
            return domaine;
        }

        public static Domaine getDomainesByTitre(Revue pTitre)
        {
            Domaine domaine;
            string req = "Select d.idDomaine,d.libelle from domaine d,titre t where d.idDomaine = t.idDomaine and t.idTitre='" ;
            req += pTitre.IdTitre + "'";

            DAOFactory.connecter();

            MySqlDataReader reader = DAOFactory.execSQLRead(req);

            if (reader.Read())
            {
                domaine = new Domaine(reader[0].ToString(), reader[1].ToString());
            }
            else
            {
                domaine = null;
            }
            DAOFactory.deconnecter();
            return domaine;
        }
        */

        /// <summary>
        /// Récupère les parutions associées à un titre de revue spécifié.
        /// </summary>
        /// <param name="pTitre">Le titre de la revue.</param>
        /// <returns>Une liste des parutions associées au titre de la revue.</returns>
        public static List<Parution> getParutionByTitre(Revue pTitre)
        {
            List<Parution> lesParutions = new List<Parution>();
            string req = "Select * from parution where idRevue = " + pTitre.Id;

            DaoFactory.connecter();

            MySqlDataReader reader = DaoFactory.execSQLRead(req);

            while (reader.Read())
            {
                Parution parution = new Parution(int.Parse(reader[1].ToString()), DateTime.Parse(reader[2].ToString()), reader[3].ToString(), pTitre.Id.ToString());
                lesParutions.Add(parution);
            }
            DaoFactory.deconnecter();
            return lesParutions;
        }

    }
}
