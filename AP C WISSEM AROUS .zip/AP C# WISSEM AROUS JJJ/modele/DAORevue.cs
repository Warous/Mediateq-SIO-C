﻿using Mediateq_AP_SIO2.metier;
using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec les données des revues dans la base de données.
    /// </summary>
    internal class DAORevue
    {
        /// <summary>
        /// Récupère toutes les revues de la base de données.
        /// </summary>
        /// <returns>Une liste contenant toutes les revues.</returns>
        public static List<Revue> GetAll()
        {
            List<Revue> listRevue = new List<Revue>();

            string req = $"SELECT * FROM revue";

            List<List<string>> listRawRevue = ManageBase.GetList(req, 7);

            foreach (List<string> rawRevue in listRawRevue)
            {
                int idRevue = Convert.ToInt32(rawRevue[0]);
                string titre = rawRevue[1];
                string empruntable = rawRevue[2];
                string periodicite = rawRevue[3];
                int delai_miseadispo = Convert.ToInt32(rawRevue[4]);
                DateTime dateFinAbonnement = DateTime.Parse(rawRevue[5]);
                int idDescripteur = Convert.ToInt32(rawRevue[6]);
                Descripteur iddescripteur = Descripteur.Get(idDescripteur);
                Revue revue = new Revue(idRevue, titre, empruntable, periodicite, dateFinAbonnement, delai_miseadispo, iddescripteur);
                listRevue.Add(revue);
            }

            return listRevue;
        }

        /// <summary>
        /// Récupère une revue à partir de son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant de la revue.</param>
        /// <returns>La revue correspondant à l'identifiant spécifié.</returns>
        public static Revue Get(int id)
        {
            string req = $"SELECT * FROM revue WHERE id = {id}";
            List<string> listRawRevue = new List<string>();
            listRawRevue = ManageBase.GetOne(req, 7);
            int idRevue = Convert.ToInt32(listRawRevue[0]);
            string titre = listRawRevue[1];
            string empruntable = listRawRevue[2];
            string periodicite = listRawRevue[3];
            int delai_miseadispo = Convert.ToInt32(listRawRevue[4]);
            DateTime dateFinAbonnement = DateTime.Parse(listRawRevue[5]);
            int idDescripteur = Convert.ToInt32(listRawRevue[6]);
            Descripteur iddescripteur = Descripteur.Get(idDescripteur);
            Revue revue = new Revue(id, titre, empruntable, periodicite, dateFinAbonnement, delai_miseadispo, iddescripteur);
            return revue;
        }
    }
}
