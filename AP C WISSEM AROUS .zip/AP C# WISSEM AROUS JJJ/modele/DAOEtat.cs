﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mediateq_AP_SIO2.metier;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec la table Etat dans la base de données.
    /// </summary>
    public class DAOEtat
    {
        /// <summary>
        /// Récupère un état spécifique par son ID depuis la base de données.
        /// </summary>
        /// <param name="id">L'ID de l'état à récupérer.</param>
        /// <returns>L'état correspondant à l'ID spécifié.</returns>
        public static Etat Get(int id)
        {
            string req = $"SELECT * FROM etat WHERE id = {id}";
            List<string> listRawDocument = new List<string>();
            listRawDocument = ManageBase.GetOne(req, 2);
            int idEtat = Convert.ToInt32(listRawDocument[0]);
            string libelle = listRawDocument[1];
            Etat etat = new Etat(idEtat, libelle);
            return etat;
        }

        /// <summary>
        /// Récupère tous les états depuis la base de données.
        /// </summary>
        /// <returns>Une liste de tous les états.</returns>
        public static List<Etat> GetAll()
        {
            List<Etat> listEtat = new List<Etat>();

            string req = $"SELECT * FROM etat";

            List<List<string>> listRawExemplaire = ManageBase.GetList(req, 2);

            foreach (List<string> rawEmplaire in listRawExemplaire)
            {
                int idEtat = Convert.ToInt32(rawEmplaire[0]);
                string libelle = rawEmplaire[1];
                Etat etat = new Etat(idEtat, libelle);
                listEtat.Add(etat);
            }

            return listEtat;
        }
    }
}
