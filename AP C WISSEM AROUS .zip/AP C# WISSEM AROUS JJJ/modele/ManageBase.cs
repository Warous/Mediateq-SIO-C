﻿using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Classe utilitaire pour la gestion des requêtes SQL et des résultats.
    /// </summary>
    public static class ManageBase
    {
        /// <summary>
        /// Exécute une requête SQL qui renvoie plusieurs lignes de résultats.
        /// </summary>
        /// <param name="request">La requête SQL à exécuter.</param>
        /// <param name="nbColumn">Le nombre de colonnes dans le résultat de la requête.</param>
        /// <returns>Une liste de listes de chaînes représentant les résultats de la requête.</returns>
        public static List<List<string>> GetList(string request, int nbColumn)
        {
            // Liste de listes pour stocker les résultats
            List<List<string>> listOfListResult = new List<List<string>>();

            // Connexion à la base de données
            DaoFactory.connecter();

            // Exécution de la requête SQL
            MySqlDataReader reader = DaoFactory.execSQLRead(request);

            // Traitement des résultats
            while (reader.Read())
            {
                List<string> listResult = new List<string>();

                // Récupération des valeurs de chaque colonne
                for (int i = 0; i < nbColumn; i++)
                {
                    listResult.Add(reader[i].ToString());
                }

                // Ajout de la liste des valeurs à la liste principale
                listOfListResult.Add(listResult);
            }

            // Déconnexion de la base de données
            DaoFactory.deconnecter();

            return listOfListResult;
        }

        /// <summary>
        /// Exécute une requête SQL qui renvoie une seule ligne de résultat.
        /// </summary>
        /// <param name="request">La requête SQL à exécuter.</param>
        /// <param name="nbColumn">Le nombre de colonnes dans le résultat de la requête.</param>
        /// <returns>Une liste de chaînes représentant la ligne de résultat de la requête.</returns>
        public static List<string> GetOne(string request, int nbColumn)
        {
            // Liste pour stocker les valeurs de la ligne de résultat
            List<string> listResult = new List<string>();

            // Connexion à la base de données
            DaoFactory.connecter();

            // Exécution de la requête SQL
            MySqlDataReader reader = DaoFactory.execSQLRead(request);

            // Traitement du résultat
            if (reader.Read())
            {
                // Récupération des valeurs de chaque colonne
                for (int i = 0; i < nbColumn; i++)
                {
                    listResult.Add(reader[i].ToString());
                }
            }
            else
            {
                // Aucun résultat trouvé, retourne null
                listResult = null;
            }

            // Déconnexion de la base de données
            DaoFactory.deconnecter();

            return listResult;
        }
    }
}
