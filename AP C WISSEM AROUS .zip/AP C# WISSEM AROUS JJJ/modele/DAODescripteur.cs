﻿using Mediateq_AP_SIO2.metier;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec la table descripteur dans la base de données.
    /// </summary>
    internal class DAODescripteur
    {
        /// <summary>
        /// Récupère tous les descripteurs depuis la base de données.
        /// </summary>
        /// <returns>Une liste de descripteurs.</returns>
        public static List<Descripteur> GetAll()
        {
            List<Descripteur> listDescripteur = new List<Descripteur>();

            string req = $"SELECT * FROM descripteur";

            List<List<string>> listRawDescripteur = ManageBase.GetList(req, 2);

            foreach (List<string> rawDescripteur in listRawDescripteur)
            {
                int idDescripteur = Convert.ToInt32(rawDescripteur[0]);
                string libelle = rawDescripteur[1];
                Descripteur descripteur = new Descripteur(idDescripteur, libelle);
                listDescripteur.Add(descripteur);
            }

            return listDescripteur;
        }

        /// <summary>
        /// Récupère un descripteur spécifique par son ID depuis la base de données.
        /// </summary>
        /// <param name="id">L'ID du descripteur à récupérer.</param>
        /// <returns>Le descripteur correspondant à l'ID spécifié.</returns>
        public static Descripteur Get(int id)
        {
            string req = $"SELECT * FROM descripteur WHERE id = {id}";
            List<string> listRawDescripteur = new List<string>();
            listRawDescripteur = ManageBase.GetOne(req, 2);
            int idDescripteur = Convert.ToInt32(listRawDescripteur[0]);
            string libelle = listRawDescripteur[1];
            Descripteur descripteur = new Descripteur(idDescripteur, libelle);
            return descripteur;
        }
    }
}
