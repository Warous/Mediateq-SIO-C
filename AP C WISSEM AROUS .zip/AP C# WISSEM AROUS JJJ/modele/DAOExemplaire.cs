﻿using Mediateq_AP_SIO2.metier;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Mediateq_AP_SIO2.modele;
using System.Xml.Linq;

namespace Mediateq_AP_SIO2
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec les exemplaires dans la base de données.
    /// </summary>
    class DAOExemplaire
    {
        /// <summary>
        /// Récupère un exemplaire spécifique par son document et son numéro.
        /// </summary>
        /// <param name="documentCible">Le document associé à l'exemplaire.</param>
        /// <param name="numeroCible">Le numéro de l'exemplaire.</param>
        /// <returns>L'exemplaire correspondant au document et au numéro spécifiés.</returns>
        public static Exemplaire Get(Document documentCible, int numeroCible)
        {
            string req = $"SELECT * FROM exemplaire WHERE idDocument = {documentCible.Id} AND numero = {numeroCible}";
            List<string> listRawEmplaire = new List<string>();
            listRawEmplaire = ManageBase.GetOne(req, 5);
            int idDocument = Convert.ToInt32(listRawEmplaire[0]);
            int numero = Convert.ToInt32(listRawEmplaire[1]);
            DateTime dateAchat = DateTime.Parse(listRawEmplaire[2]);
            int idRayon = Convert.ToInt32(listRawEmplaire[3]);
            int idEtat = Convert.ToInt32(listRawEmplaire[4]);
            Document document = Document.Get(idDocument);
            Rayon rayon = Rayon.Get(idRayon);
            Etat etat = Etat.Get(idEtat);
            Exemplaire exemplaire = new Exemplaire(document, numero, dateAchat, rayon, etat);
            return exemplaire;
        }

        /// <summary>
        /// Récupère tous les exemplaires associés à un document spécifique.
        /// </summary>
        /// <param name="documentCible">Le document associé aux exemplaires.</param>
        /// <returns>Une liste d'exemplaires associés au document spécifié.</returns>
        public static List<Exemplaire> GetAllByDocument(Document documentCible)
        {
            List<Exemplaire> listExemplaire = new List<Exemplaire>();

            string req = $"SELECT * FROM exemplaire WHERE idDocument = {documentCible.Id}";

            List<List<string>> listRawExemplaire = ManageBase.GetList(req, 5);

            foreach (List<string> rawEmplaire in listRawExemplaire)
            {
                int idDocument = Convert.ToInt32(rawEmplaire[0]);
                int numero = Convert.ToInt32(rawEmplaire[1]);
                DateTime dateAchat = DateTime.Parse(rawEmplaire[2]);
                int idRayon = Convert.ToInt32(rawEmplaire[3]);
                int idEtat = Convert.ToInt32(rawEmplaire[4]);

                Document document = Document.Get(idDocument);
                Rayon rayon = Rayon.Get(idRayon);
                Etat etat = Etat.Get(idEtat);

                Exemplaire exemplaire = new Exemplaire(document, numero, dateAchat, rayon, etat);
                listExemplaire.Add(exemplaire);
            }

            return listExemplaire;
        }

        /// <summary>
        /// Récupère tous les exemplaires de la base de données.
        /// </summary>
        /// <returns>Une liste de tous les exemplaires.</returns>
        public static List<Exemplaire> GetAll()
        {
            List<Exemplaire> listExemplaire = new List<Exemplaire>();

            string req = $"SELECT * FROM exemplaire";

            List<List<string>> listRawExemplaire = ManageBase.GetList(req, 5);

            foreach (List<string> rawExemplaire in listRawExemplaire)
            {
                int idDocument = Convert.ToInt32(rawExemplaire[0]);
                int numero = Convert.ToInt32(rawExemplaire[1]);
                DateTime dateAchat = DateTime.Parse(rawExemplaire[2]);
                int idRayon = Convert.ToInt32(rawExemplaire[3]);
                int idEtat = Convert.ToInt32(rawExemplaire[4]);
                Document document = Document.Get(idDocument);
                Rayon rayon = Rayon.Get(idRayon);
                Etat etat = Etat.Get(idEtat);
                Exemplaire exemplaire = new Exemplaire(document, numero, dateAchat, rayon, etat);
                listExemplaire.Add(exemplaire);
            }

            return listExemplaire;
        }

        /// <summary>
        /// Récupère tous les exemplaires associés à un état spécifique.
        /// </summary>
        /// <param name="idEtat">L'identifiant de l'état des exemplaires.</param>
        /// <returns>Une liste d'exemplaires associés à l'état spécifié.</returns>
        public static List<Exemplaire> GetAllByEtat(int idEtat)
        {
            List<Exemplaire> listExemplaire = new List<Exemplaire>();

            string req = $"SELECT * FROM exemplaire WHERE idEtat = {idEtat}";

            List<List<string>> listRawExemplaire = ManageBase.GetList(req, 5);

            foreach (List<string> rawExemplaire in listRawExemplaire)
            {
                int idDocument = Convert.ToInt32(rawExemplaire[0]);
                int numero = Convert.ToInt32(rawExemplaire[1]);
                DateTime dateAchat = DateTime.Parse(rawExemplaire[2]);
                int idRayon = Convert.ToInt32(rawExemplaire[3]);
                int lidEtat = Convert.ToInt32(rawExemplaire[4]);
                Document document = Document.Get(idDocument);
                Rayon rayon = Rayon.Get(idRayon);
                Etat etat = Etat.Get(lidEtat);
                Exemplaire exemplaire = new Exemplaire(document, numero, dateAchat, rayon, etat);
                listExemplaire.Add(exemplaire);
            }

            return listExemplaire;
        }

        /// <summary>
        /// Insère un signalement pour un exemplaire spécifique.
        /// </summary>
        /// <param name="document">Le document associé à l'exemplaire.</param>
        /// <param name="exemplaireCible">L'exemplaire concerné par le signalement.</param>
        /// <param name="id">L'identifiant du signalement.</param>
        /// <param name="abonne">L'abonné ayant effectué le signalement.</param>
        public static void InsertSignalement(Document document, Exemplaire exemplaireCible, int id, Abonne abonne)
        {
            string req = $"INSERT INTO signalement (idDocument, numeroExemplaire, idEtat, nomAbonne) VALUES ({document.Id}, {exemplaireCible.Numero}, 3, '{abonne.Nom}')";
            DaoFactory.connecter();
            MySqlDataReader reader = DaoFactory.execSQLRead(req);
            DaoFactory.deconnecter();
        }

        /// <summary>
        /// Met à jour l'état d'un exemplaire spécifique.
        /// </summary>
        /// <param name="document">Le document associé à l'exemplaire.</param>
        /// <param name="exemplaire">L'exemplaire à mettre à jour.</param>
        /// <param name="id">L'identifiant du nouvel état.</param>
        public static void UpdateExemplaire(Document document, Exemplaire exemplaire, int id)
        {
            string req = $"UPDATE exemplaire SET idEtat = {id} WHERE idDocument = {document.Id} AND numero = {exemplaire.Numero}";
            DaoFactory.connecter();
            MySqlDataReader reader = DaoFactory.execSQLRead(req);
            DaoFactory.deconnecter();
        }

        /// <summary>
        /// Met à jour l'état d'un exemplaire spécifique.
        /// </summary>
        /// <param name="etat">Le nouvel état de l'exemplaire.</param>
        /// <param name="document">Le document associé à l'exemplaire.</param>
        /// <param name="exemplaire">L'exemplaire à mettre à jour.</param>
        public static void UpdateEtat(Etat etat, Document document, Exemplaire exemplaire)
        {
            string req = $"UPDATE exemplaire SET idEtat = {etat.Id} WHERE idDocument = {document.Id} AND numero = {exemplaire.Numero}";
            DaoFactory.connecter();
            MySqlDataReader reader = DaoFactory.execSQLRead(req);
            DaoFactory.deconnecter();
        }
    }
}
