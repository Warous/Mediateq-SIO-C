﻿using Mediateq_AP_SIO2.metier;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec les données des rayons dans la base de données.
    /// </summary>
    internal class DAORayon
    {
        /// <summary>
        /// Récupère un rayon à partir de son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant du rayon.</param>
        /// <returns>Le rayon correspondant à l'identifiant spécifié.</returns>
        public static Rayon Get(int id)
        {
            string req = $"SELECT * FROM rayon WHERE id = {id}";
            List<string> listRawRayon = new List<string>();
            listRawRayon = ManageBase.GetOne(req, 2);
            int idRayon = Convert.ToInt32(listRawRayon[0]);
            string libelle = listRawRayon[1];
            Rayon rayon = new Rayon(idRayon, libelle);
            return rayon;
        }
    }
}
