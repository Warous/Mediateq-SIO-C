﻿using Mediateq_AP_SIO2.metier;
using System.Collections.Generic;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Fournit des méthodes pour accéder et manipuler les données des comptes dans la base de données.
    /// </summary>
    internal class DAOCompte
    {
        /// <summary>
        /// Récupère tous les comptes de la base de données.
        /// </summary>
        /// <returns>Une liste contenant tous les comptes.</returns>
        public static List<Compte> GetAll()
        {
            List<Compte> listCompte = new List<Compte>();

            string req = $"SELECT * FROM compte";

            List<List<string>> listRawCompte = ManageBase.GetList(req, 5);

            foreach (List<string> rawCompte in listRawCompte)
            {
                string nom = rawCompte[0];
                string prenom = rawCompte[1];
                string identifiant = rawCompte[2];
                string password = rawCompte[3];
                string service = rawCompte[4];
                Compte compte = new Compte(nom, prenom, identifiant, password, service);
                listCompte.Add(compte);
            }

            return listCompte;
        }
    }
}
