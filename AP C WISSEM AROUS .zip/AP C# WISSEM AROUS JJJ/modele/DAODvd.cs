﻿using Mediateq_AP_SIO2.metier;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec la table DVD dans la base de données.
    /// </summary>
    internal class DAODvd
    {
        /// <summary>
        /// Récupère tous les DVDs depuis la base de données.
        /// </summary>
        /// <returns>Une liste de DVDs.</returns>
        public static List<Dvd> GetAll()
        {
            List<Dvd> listDvd = new List<Dvd>();

            string req = $"SELECT * FROM dvd JOIN document ON dvd.idDocument = document.id";

            List<List<string>> listRawDvd = ManageBase.GetList(req, 10);

            foreach (List<string> rawDvd in listRawDvd)
            {
                int idDvd = Convert.ToInt32(rawDvd[0]);
                string synopsis = rawDvd[1];
                string realisateur = rawDvd[2];
                int duree = Convert.ToInt32(rawDvd[3]);
                string titre = rawDvd[5];
                string image = rawDvd[6];
                int commandeEnCours;
                if (rawDvd[7] != "")
                {
                    commandeEnCours = Convert.ToInt32(rawDvd[7]);
                }
                else
                {
                    commandeEnCours = 0;
                }
                int idPublic = Convert.ToInt32(rawDvd[8]);
                PublicCible publicCible = PublicCible.Get(idPublic);
                bool existe = Convert.ToBoolean(rawDvd[9]);
                Dvd dvd = new Dvd(idDvd, titre, synopsis, realisateur, duree, image, commandeEnCours, publicCible, existe);
                listDvd.Add(dvd);
            }

            return listDvd;
        }

        /// <summary>
        /// Récupère un DVD spécifique par son ID de document depuis la base de données.
        /// </summary>
        /// <param name="idDocument">L'ID du document correspondant au DVD à récupérer.</param>
        /// <returns>Le DVD correspondant à l'ID de document spécifié.</returns>
        public static Dvd Get(int idDocument)
        {
            Dvd dvd;
            List<string> rowDvd = ManageBase.GetOne("SELECT * FROM dvd JOIN document ON dvd.idDocument = document.id WHERE dvd.idDocument = " + idDocument, 10);

            if (rowDvd == null) return null;

            int id = Convert.ToInt32(rowDvd[0]);
            string titre = rowDvd[5];
            string synopsis = rowDvd[1];
            string realisateur = rowDvd[2];
            int duree = Convert.ToInt32(rowDvd[3]);
            string image = rowDvd[6];
            int commandeEnCours;
            if (rowDvd[7] != "")
            {
                commandeEnCours = Convert.ToInt32(rowDvd[7]);
            }
            else
            {
                commandeEnCours = 0;
            }

            int idPublic = Convert.ToInt32(rowDvd[8]);
            PublicCible publicCible = PublicCible.Get(idPublic);
            bool existe = Convert.ToBoolean(rowDvd[9]);
            dvd = new Dvd(id, titre, synopsis, realisateur, duree, image, commandeEnCours, publicCible, existe);
            dvd.Synopsis = synopsis;
            dvd.Image = image;
            dvd.Duree = duree;

            return dvd;
        }

        /// <summary>
        /// Crée un nouveau DVD dans la base de données.
        /// </summary>
        /// <param name="id">L'ID du DVD.</param>
        /// <param name="titre">Le titre du DVD.</param>
        /// <param name="synopsis">Le synopsis du DVD.</param>
        /// <param name="realisateur">Le réalisateur du DVD.</param>
        /// <param name="duree">La durée du DVD en minutes.</param>
        /// <param name="image">Le chemin de l'image du DVD.</param>
        /// <param name="commandeencours">Le nombre de commandes en cours pour le DVD.</param>
        /// <param name="publiccible">L'ID de la public cible du DVD.</param>
        public static void CreateDvd(int id, string titre, string synopsis, string realisateur, int duree, string image, int commandeencours, int publiccible)
        {
            // Récupération du plus grand ID dans la table document
            string req2 = $"SELECT MAX(id) FROM `document`;";
            DaoFactory.connecter();
            MySqlDataReader reader2 = DaoFactory.execSQLRead(req2);

            if (reader2.Read())
            {
                id = reader2.GetInt32(0); // La valeur MAX(id) est dans la première colonne (indice 0)
            }
            int maxId = id + 1;
            DaoFactory.deconnecter();

            // Insertion du DVD dans la table document
            string req = $"INSERT INTO Document (id, titre, image, commandeEnCours, idPublic) VALUES ({maxId}, '{titre}', '{image}',  {commandeencours} , {publiccible})";
            string req1 = $"INSERT INTO Dvd (idDocument, synopsis, réalisateur, duree) VALUES ({maxId}, '{synopsis}', '{realisateur}', '{duree}')";

            DaoFactory.connecter();
            MySqlDataReader reader = DaoFactory.execSQLRead(req);
            DaoFactory.deconnecter();

            DaoFactory.connecter();
            MySqlDataReader reader1 = DaoFactory.execSQLRead(req1);
            DaoFactory.deconnecter();
        }

        /// <summary>
        /// Met à jour les informations d'un DVD dans la base de données.
        /// </summary>
        /// <param name="document">Le document correspondant au DVD à mettre à jour.</param>
        /// <param name="synopsis">Le nouveau synopsis du DVD.</param>
        /// <param name="realisateur">Le nouveau réalisateur du DVD.</param>
        /// <param name="duree">La nouvelle durée du DVD en minutes.</param>
        public static void UpdateDvd(Document document, string synopsis, string realisateur, int duree)
        {
            int id = document.Id;
            string req = $"UPDATE dvd SET synopsis = '{synopsis}', réalisateur = '{realisateur}', duree = '{duree}' WHERE idDocument = {id};";
            DaoFactory.connecter();
            MySqlDataReader reader = DaoFactory.execSQLRead(req);
            DaoFactory.deconnecter();
        }

        /// <summary>
        /// Supprime un DVD de la base de données.
        /// </summary>
        /// <param name="document">Le document correspondant au DVD à supprimer.</param>
        public static void DeleteDvd(Document document)
        {
            int id = document.Id;
            // Suppression du DVD de la table dvd
            string req = $"DELETE FROM dvd WHERE idDocument = {id};";
            DaoFactory.connecter();
            MySqlDataReader reader = DaoFactory.execSQLRead(req);
            DaoFactory.deconnecter();

            // Mise à jour de l'état du document dans la table document
            string req1 = $"UPDATE document SET existe = '1' WHERE id = {id};";
            DaoFactory.connecter();
            MySqlDataReader reader1 = DaoFactory.execSQLRead(req1);
            DaoFactory.deconnecter();
        }
    }
}
