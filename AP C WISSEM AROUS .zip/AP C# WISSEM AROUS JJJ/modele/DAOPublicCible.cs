﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Mediateq_AP_SIO2.metier;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec les données des publics cibles dans la base de données.
    /// </summary>
    class DAOPublicCible
    {
        /// <summary>
        /// Récupère un public cible à partir de son identifiant.
        /// </summary>
        /// <param name="id">L'identifiant du public cible.</param>
        /// <returns>Le public cible correspondant à l'identifiant spécifié.</returns>
        public static PublicCible Get(int id)
        {
            string req = $"SELECT * FROM public WHERE id = {id}";
            List<string> listRawDocument = new List<string>();
            listRawDocument = ManageBase.GetOne(req, 2);
            int idPublic = Convert.ToInt32(listRawDocument[0]);
            string libelle = listRawDocument[1].ToString();
            PublicCible Public = new PublicCible(idPublic, libelle);
            return Public;
        }

        /// <summary>
        /// Récupère un public cible à partir de son libellé.
        /// </summary>
        /// <param name="libelle">Le libellé du public cible.</param>
        /// <returns>Le public cible correspondant au libellé spécifié.</returns>
        public static PublicCible Get(string libelle)
        {
            string req = $"SELECT * FROM public WHERE libelle = '{libelle}'";
            List<string> listRawDocument = new List<string>();
            listRawDocument = ManageBase.GetOne(req, 2);
            int id = Convert.ToInt32(listRawDocument[0]);
            string libellePublic = listRawDocument[1].ToString();
            PublicCible Public = new PublicCible(id, libellePublic);
            return Public;
        }

        /// <summary>
        /// Récupère tous les publics cibles.
        /// </summary>
        /// <returns>Une liste contenant tous les publics cibles présents dans la base de données.</returns>
        public static List<PublicCible> GetAll()
        {
            List<PublicCible> listPublicCible = new List<PublicCible>();

            string req = $"SELECT * FROM public";

            List<List<string>> listRawPublicCible = ManageBase.GetList(req, 2);

            foreach (List<string> rawPublicCible in listRawPublicCible)
            {
                int idPublicCible = Convert.ToInt32(rawPublicCible[0]);
                string libelle = rawPublicCible[1];
                PublicCible publiccible = new PublicCible(idPublicCible, libelle);
                listPublicCible.Add(publiccible);
            }

            return listPublicCible;
        }
    }
}
