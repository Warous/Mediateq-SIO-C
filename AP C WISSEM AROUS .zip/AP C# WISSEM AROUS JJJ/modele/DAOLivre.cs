﻿using Google.Protobuf.WellKnownTypes;
using Mediateq_AP_SIO2.metier;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Fournit des méthodes pour interagir avec les livres dans la base de données.
    /// </summary>
    class DAOLivre
    {
        /// <summary>
        /// Récupère tous les livres de la base de données.
        /// </summary>
        /// <returns>Une liste de tous les livres.</returns>
        public static List<Livre> GetAll()
        {
            List<Livre> listLivre = new List<Livre>();
            List<List<string>> listRowLivre = ManageBase.GetList("SELECT * FROM livre JOIN document ON livre.idDocument = document.id", 10);

            foreach (List<string> rowLivre in listRowLivre)
            {
                int id = Convert.ToInt32(rowLivre[0]);
                string ISBN = rowLivre[1];
                string auteur = rowLivre[2];
                string collection = rowLivre[3];
                string titre = rowLivre[5];
                string image = rowLivre[6];
                int commandeEnCours;
                if (rowLivre[7] != "")
                {
                    commandeEnCours = Convert.ToInt32(rowLivre[7]);
                }
                else
                {
                    commandeEnCours = 0;
                }

                int idPublic = Convert.ToInt32(rowLivre[8]);
                PublicCible publicCible = PublicCible.Get(idPublic);
                bool existe = Convert.ToBoolean(rowLivre[9]);
                Livre livre = new Livre(id, titre, ISBN, auteur, collection, image, commandeEnCours, publicCible, existe);
                livre.Collection = collection;
                livre.Image = image;
                livre.CommandeEnCours = commandeEnCours;

                listLivre.Add(livre);
            }

            return listLivre;
        }

        /// <summary>
        /// Récupère un livre spécifique par son identifiant de document.
        /// </summary>
        /// <param name="idDocument">L'identifiant du document associé au livre.</param>
        /// <returns>Le livre correspondant à l'identifiant de document spécifié.</returns>
        public static Livre Get(int idDocument)
        {
            Livre livre;
            List<string> rowLivre = ManageBase.GetOne("SELECT * FROM livre JOIN document ON livre.idDocument = document.id WHERE livre.idDocument = " + idDocument, 10);

            if (rowLivre == null) return null;

            int id = Convert.ToInt32(rowLivre[0]);
            string ISBN = rowLivre[1];
            string auteur = rowLivre[2];
            string collection = rowLivre[3];
            string titre = rowLivre[5];
            string image = rowLivre[6];
            int commandeEnCours;
            if (rowLivre[7] != "")
            {
                commandeEnCours = Convert.ToInt32(rowLivre[7]);
            }
            else
            {
                commandeEnCours = 0;
            }

            int idPublic = Convert.ToInt32(rowLivre[8]);
            PublicCible publicCible = PublicCible.Get(idPublic);
            bool existe = Convert.ToBoolean(rowLivre[9]);
            livre = new Livre(id, titre, ISBN, auteur, collection, image, commandeEnCours, publicCible, existe);
            livre.Collection = collection;
            livre.Image = image;
            livre.CommandeEnCours = commandeEnCours;

            return livre;
        }

        /// <summary>
        /// Crée un nouveau livre dans la base de données.
        /// </summary>
        /// <param name="id">L'identifiant du livre.</param>
        /// <param name="titre">Le titre du livre.</param>
        /// <param name="ISBN">Le numéro ISBN du livre.</param>
        /// <param name="auteur">L'auteur du livre.</param>
        /// <param name="collection">La collection à laquelle appartient le livre.</param>
        /// <param name="image">Le chemin de l'image du livre.</param>
        /// <param name="commandeencours">Le nombre de commandes en cours pour le livre.</param>
        /// <param name="publiccible">L'identifiant de la cible publique du livre.</param>
        public static void CreateLivre(int id, string titre, string ISBN, string auteur, string collection, string image, int commandeencours, int publiccible)
        {
            string req2 = $"SELECT MAX(id) FROM `document`;";

            DaoFactory.connecter();
            MySqlDataReader reader2 = DaoFactory.execSQLRead(req2);

            if (reader2.Read())
            {
                id = reader2.GetInt32(0); // La valeur MAX(id) est dans la première colonne (indice 0)
            }
            int maxId = id + 1;
            DaoFactory.deconnecter();


            string req = $"INSERT INTO Document (id, titre, image, commandeEnCours, idPublic) VALUES ({maxId}, '{titre}', '{image}',  {commandeencours} , {publiccible})";
            string req1 = $"INSERT INTO Livre (idDocument, ISBN, auteur, collection) VALUES ({maxId}, {ISBN}, '{auteur}', '{collection}')";

            DaoFactory.connecter();
            MySqlDataReader reader = DaoFactory.execSQLRead(req);
            DaoFactory.deconnecter();

            DaoFactory.connecter();
            MySqlDataReader reader1 = DaoFactory.execSQLRead(req1);
            DaoFactory.deconnecter();
        }

        /// <summary>
        /// Met à jour les informations d'un livre dans la base de données.
        /// </summary>
        /// <param name="document">Le document associé au livre.</param>
        /// <param name="ISBN">Le nouveau numéro ISBN du livre.</param>
        /// <param name="auteur">Le nouvel auteur du livre.</param>
        /// <param name="collection">La nouvelle collection à laquelle appartient le livre.</param>
        public static void UpdateLivre(Document document, string ISBN, string auteur, string collection)
        {
            int id = document.Id;
            string req = $"UPDATE livre SET isbn = '{ISBN}', auteur = '{auteur}', collection = '{collection}' WHERE idDocument = {id};";
            DaoFactory.connecter();
            MySqlDataReader reader = DaoFactory.execSQLRead(req);
            DaoFactory.deconnecter();
        }

        /// <summary>
        /// Supprime un livre de la base de données.
        /// </summary>
        /// <param name="document">Le document associé au livre à supprimer.</param>
        public static void DeleteLivre(Document document)
        {
            int id = document.Id;
            string req = $"DELETE FROM livre WHERE idDocument = {id};";
            DaoFactory.connecter();
            MySqlDataReader reader = DaoFactory.execSQLRead(req);
            DaoFactory.deconnecter();
            string req1 = $"UPDATE document SET existe = '1' WHERE id = {id};";
            DaoFactory.connecter();
            MySqlDataReader reader1 = DaoFactory.execSQLRead(req1);
            DaoFactory.deconnecter();
        }
    }
}
