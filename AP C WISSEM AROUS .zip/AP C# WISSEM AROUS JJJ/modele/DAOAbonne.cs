﻿using Mediateq_AP_SIO2.metier;
using System;
using System.Collections.Generic;

namespace Mediateq_AP_SIO2.modele
{
    /// <summary>
    /// Fournit des méthodes pour accéder et manipuler les données des abonnés dans la base de données.
    /// </summary>
    internal class DAOAbonne
    {
        /// <summary>
        /// Récupère un abonné à partir de son nom.
        /// </summary>
        /// <param name="nom">Le nom de l'abonné à rechercher.</param>
        /// <returns>L'abonné correspondant au nom spécifié.</returns>
        public static Abonne Get(string nom)
        {
            string req = $"SELECT * FROM abonne WHERE nom = '{nom}'";
            List<string> listRawAbonne = new List<string>();
            listRawAbonne = ManageBase.GetOne(req, 5);
            int num = Convert.ToInt32(listRawAbonne[0]);
            string nomA = listRawAbonne[1];
            string prenom = listRawAbonne[2];
            string mdp = listRawAbonne[3];
            DateTime date_fin_abonnement = DateTime.Parse(listRawAbonne[4]);
            Abonne abonne = new Abonne(num, nomA, prenom, mdp, date_fin_abonnement);
            return abonne;
        }

        /// <summary>
        /// Récupère tous les abonnés de la base de données.
        /// </summary>
        /// <returns>Une liste contenant tous les abonnés.</returns>
        public static List<Abonne> GetAll()
        {
            List<Abonne> listAbonne = new List<Abonne>();

            string req = $"SELECT * FROM abonne";

            List<List<string>> listRawAbonne = ManageBase.GetList(req, 5);

            foreach (List<string> rawAbonne in listRawAbonne)
            {
                int num = Convert.ToInt32(rawAbonne[0]);
                string nom = rawAbonne[1];
                string prenom = rawAbonne[2];
                string mdp = rawAbonne[3];
                DateTime date_fin_abonnement = DateTime.Parse(rawAbonne[4]);
                Abonne abonne = new Abonne(num, nom, prenom, mdp, date_fin_abonnement);
                listAbonne.Add(abonne);
            }

            return listAbonne;
        }

        /// <summary>
        /// Récupère tous les signalements effectués par les abonnés.
        /// </summary>
        /// <returns>Une liste contenant tous les signalements effectués.</returns>
        public static List<Signalement> GetAllSignalement()
        {
            List<Signalement> listSignalement = new List<Signalement>();

            string req = $"SELECT * FROM signalement";

            List<List<string>> listRawExemplaire = ManageBase.GetList(req, 4);

            foreach (List<string> rawExemplaire in listRawExemplaire)
            {
                int idDocument = Convert.ToInt32(rawExemplaire[0]);
                int numero = Convert.ToInt32(rawExemplaire[1]);
                int idEtat = Convert.ToInt32(rawExemplaire[2]);
                string nomAbonne = rawExemplaire[3];
                Abonne abonne = Abonne.Get(nomAbonne);
                Document document = Document.Get(idDocument);
                Exemplaire exemplaire = Exemplaire.Get(document, numero);
                Etat etat = Etat.Get(idEtat);
                Signalement signalement = new Signalement(document, exemplaire, etat, abonne);
                listSignalement.Add(signalement);
            }

            return listSignalement;
        }
    }
}
