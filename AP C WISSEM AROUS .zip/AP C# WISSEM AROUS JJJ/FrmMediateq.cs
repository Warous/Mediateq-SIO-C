﻿using System;
using System.Collections.Generic;
using System.Drawing.Text;
using System.Security;
using System.Windows.Forms;
using Mediateq_AP_SIO2.metier;
using Mediateq_AP_SIO2.modele;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.AxHost;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Button = System.Windows.Forms.Button;
using TextBox = System.Windows.Forms.TextBox;

namespace Mediateq_AP_SIO2
{
    public partial class FrmMediateq : Form
    {
        #region Variables globales

        static List<PublicCible> lesCategories;
        static List<Descripteur> lesDescripteurs;
        static List<Revue> lesRevues;
        static List<Livre> lesLivres;
        static List<Dvd> lesDvd;
        static List<Etat> lesEtats;
        static List<Exemplaire> lesExemplaires;
        static List<Document> lesDocuments;
        static List<Exemplaire> lesExemplairesParDoc;
        static List<Abonne> lesAbonnes;
        static List<Signalement> lesSignalements;
        static List<Exemplaire> lesExemplairesInutilisables;
        static List<Compte> lesComptes;

        #endregion


        #region Procédures évènementielles

        public FrmMediateq()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Charge les données et initialise l'interface utilisateur lors du chargement du formulaire.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode initialise la connexion à la base de données et charge les objets nécessaires en mémoire.
        /// En cas d'erreur lors de la création de la connexion ou du chargement des objets, un message d'erreur est affiché.
        /// </remarks>
        private void FrmMediateq_Load(object sender, EventArgs e)
        {
            try
            {
                // Création de la connexion avec la base de données
                DaoFactory.creerConnection();

                // Chargement des objets en mémoire
                lesDescripteurs = Descripteur.GetAll();
                lesRevues = Revue.GetAll();

                // Effacer les onglets et ajouter le premier onglet
                tabOngletsApplication.TabPages.Clear();
                tabOngletsApplication.TabPages.Add(tabPage3);
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors du chargement du formulaire
                MessageBox.Show("Une erreur s'est produite lors du chargement du formulaire : " + ex.Message);
            }
        }

        #endregion


        #region Connexion

        //  salt = LSnAk9b5A1DdbFod71a3Xw==
        //  Password = p4SlCP98/4GVbrhkGZaLzEr05FaoZBTJE3WI3IOIZPI=

        /// <summary>
        /// Gère l'événement de clic sur le bouton de connexion.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        private void bouton_Connexion(object sender, EventArgs e)
        {
            try
            {
                string salt = "LSnAk9b5A1DdbFod71a3Xw==";
                lesComptes = Compte.GetAll();
                string user = textBox3.Text;
                string mdp = textBox4.Text;
                string mdpHash = Hash.HashPassword(mdp, salt);
                foreach (Compte compte in lesComptes)
                {
                    if (user == compte.Identifiant)
                    {
                        if (mdpHash == compte.Password)
                        {
                            tabOngletsApplication.TabPages.Remove(tabPage3);
                            tabOngletsApplication.TabPages.Add(tabParutions);
                            tabOngletsApplication.TabPages.Add(tabTitres);
                            tabOngletsApplication.TabPages.Add(tabLivres);
                            tabOngletsApplication.TabPages.Add(tabDVD);
                            tabOngletsApplication.TabPages.Add(tabPage1);
                            tabOngletsApplication.TabPages.Add(Signalement);
                            tabOngletsApplication.TabPages.Add(tabPage2);
                            return; // Sortie de la méthode après la connexion réussie
                        }
                    }
                }

                // Si aucun compte correspondant n'est trouvé ou si le mot de passe est incorrect
                MessageBox.Show("Identifiant ou mot de passe incorrect.");
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la connexion
                MessageBox.Show("Une erreur s'est produite lors de la connexion : " + ex.Message);
            }
        }



        #endregion


        #region Parutions
        //-----------------------------------------------------------
        // ONGLET "PARUTIONS"
        //------------------------------------------------------------

        /// <summary>
        /// Gère l'événement déclenché lorsque l'utilisateur entre dans l'onglet "Parutions".
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode charge les titres des revues dans une combobox lors de l'entrée dans l'onglet "Parutions".
        /// En cas d'erreur lors du chargement des titres, un message d'erreur est affiché.
        /// </remarks>
        private void tabParutions_Enter(object sender, EventArgs e)
        {
            try
            {
                cbxTitres.DataSource = lesRevues;
                cbxTitres.DisplayMember = "titre";
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors du chargement des titres
                MessageBox.Show("Une erreur s'est produite lors du chargement des titres : " + ex.Message);
            }
        }


        /// <summary>
        /// Gère l'événement déclenché lorsque la sélection de la combobox des titres change.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode récupère les parutions associées au titre sélectionné et les affiche dans un DataGridView.
        /// En cas d'erreur lors de la récupération ou de l'affichage des parutions, un message d'erreur est affiché.
        /// </remarks>
        private void cbxTitres_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<Parution> lesParutions;

                Revue titreSelectionne = (Revue)cbxTitres.SelectedItem;
                lesParutions = DAOPresse.getParutionByTitre(titreSelectionne);

                // Réinitialisation du dataGridView
                dgvParutions.Rows.Clear();

                // Parcours de la collection des parutions et alimentation du DataGridView
                foreach (Parution parution in lesParutions)
                {
                    dgvParutions.Rows.Add(parution.Numero, parution.DateParution, parution.Photo);
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la récupération ou de l'affichage des parutions
                MessageBox.Show("Une erreur s'est produite lors de l'affichage des parutions : " + ex.Message);
            }
        }

        #endregion


        #region Revues
        //-----------------------------------------------------------
        // ONGLET "TITRES"
        //------------------------------------------------------------

        /// <summary>
        /// Gère l'événement déclenché lorsque l'utilisateur entre dans l'onglet "Titres".
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode charge les domaines (descripteurs) dans une combobox lors de l'entrée dans l'onglet "Titres".
        /// En cas d'erreur lors du chargement des domaines, un message d'erreur est affiché.
        /// </remarks>
        private void tabTitres_Enter(object sender, EventArgs e)
        {
            try
            {
                cbxDomaines.DataSource = lesDescripteurs;
                cbxDomaines.DisplayMember = "libelle";
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors du chargement des domaines
                MessageBox.Show("Une erreur s'est produite lors du chargement des domaines : " + ex.Message);
            }
        }


        /// <summary>
        /// Gère l'événement déclenché lorsque la sélection de la combobox des domaines (descripteurs) change.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode affiche les titres associés au domaine (descripteur) sélectionné dans un DataGridView.
        /// En cas d'erreur lors de la récupération ou de l'affichage des titres, un message d'erreur est affiché.
        /// </remarks>
        private void cbxDomaines_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                // Objet Domaine sélectionné dans la comboBox
                Descripteur domaineSelectionne = (Descripteur)cbxDomaines.SelectedItem;

                // Réinitialisation du dataGridView
                dgvTitres.Rows.Clear();

                // Parcours de la collection des titres et alimentation du DataGridView
                foreach (Revue revue in lesRevues)
                {
                    if (revue.Id == domaineSelectionne.Id)
                    {
                        dgvTitres.Rows.Add(revue.Id, revue.Titre, revue.Empruntable, revue.DateFinAbonnement, revue.DelaiMiseADispo);
                    }
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la récupération ou de l'affichage des titres
                MessageBox.Show("Une erreur s'est produite lors de l'affichage des titres : " + ex.Message);
            }
        }

        #endregion


        #region Livres
        //-----------------------------------------------------------
        // ONGLET "LIVRES"
        //-----------------------------------------------------------

        /// <summary>
        /// Gère l'événement déclenché lorsque l'utilisateur entre dans l'onglet "Livres".
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode charge les catégories, les livres et initialise les comboboxes correspondantes lors de l'entrée dans l'onglet "Livres".
        /// En cas d'erreur lors du chargement des catégories, des livres ou de l'initialisation des comboboxes, un message d'erreur est affiché.
        /// </remarks>
        private void tabLivres_Enter(object sender, EventArgs e)
        {
            try
            {
                // Chargement des objets en mémoire
                lesCategories = PublicCible.GetAll();
                lesDescripteurs = Descripteur.GetAll();
                lesLivres = Livre.GetAll();
                lesCategories = PublicCible.GetAll();

                // Chargement des catégories dans la combobox
                comboBox9.DataSource = lesCategories;
                comboBox9.DisplayMember = "libelle";

                // Chargement des livres dans les comboboxes
                comboBox10.DataSource = lesLivres;
                comboBox10.DisplayMember = "id";
                comboBox11.DataSource = lesLivres;
                comboBox11.DisplayMember = "id";
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors du chargement des catégories, des livres ou de l'initialisation des comboboxes
                MessageBox.Show("Une erreur s'est produite lors du chargement des livres : " + ex.Message);
            }
        }


        /// <summary>
        /// Gère l'événement de clic sur le bouton "Rechercher".
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode recherche le livre correspondant au numéro de document saisi et affiche ses informations dans des labels.
        /// Si le livre n'est pas trouvé, un message d'erreur est affiché.
        /// </remarks>
        private void btnRechercher_Click(object sender, EventArgs e)
        {
            try
            {
                // On réinitialise les labels
                lblNumero.Text = "";
                lblTitre.Text = "";
                lblAuteur.Text = "";
                lblCollection.Text = "";
                lblISBN.Text = "";
                lblImage.Text = "";

                // On recherche le livre correspondant au numéro de document saisi.
                // S'il n'existe pas: on affiche un popup message d'erreur
                bool trouve = false;
                foreach (Livre livre in lesLivres)
                {
                    if (livre.Id == Convert.ToInt32(txbNumDoc.Text))
                    {
                        lblNumero.Text = livre.Id.ToString();
                        lblTitre.Text = livre.Titre;
                        lblAuteur.Text = livre.Auteur;
                        lblCollection.Text = livre.Collection;
                        lblISBN.Text = livre.ISBN;
                        lblImage.Text = livre.Image;
                        trouve = true;
                    }
                }
                if (!trouve)
                    MessageBox.Show("Document non trouvé dans les livres");
            }
            catch (FormatException)
            {
                // En cas de format incorrect pour le numéro de document saisi
                MessageBox.Show("Format incorrect pour le numéro de document saisi.");
            }
            catch (Exception ex)
            {
                // En cas d'erreur inattendue
                MessageBox.Show("Une erreur s'est produite lors de la recherche du livre : " + ex.Message);
            }
        }


        /// <summary>
        /// Gère l'événement déclenché lors de la modification du texte dans le champ de saisie du titre.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode filtre les livres en fonction du titre saisi et affiche les résultats dans un DataGridView.
        /// Si une erreur survient lors de la mise à jour de l'affichage, un message d'erreur est affiché.
        /// </remarks>
        private void txbTitre_TextChanged(object sender, EventArgs e)
        {
            try
            {
                dgvLivres.Rows.Clear();

                // On parcourt tous les livres. Si le titre matche avec la saisie, on l'affiche dans le DataGridView.
                foreach (Livre livre in lesLivres)
                {
                    // On convertit le champ de saisie et le titre en minuscules pour ignorer la casse.
                    string saisieMinuscules = txbTitre.Text.ToLower();
                    string titreMinuscules = livre.Titre.ToLower();

                    // On teste si le titre du livre contient ce qui a été saisi.
                    if (titreMinuscules.Contains(saisieMinuscules))
                    {
                        dgvLivres.Rows.Add(livre.Id, livre.Titre, livre.Auteur, livre.ISBN, livre.Collection);
                    }
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la mise à jour de l'affichage
                MessageBox.Show("Une erreur s'est produite lors de la recherche des livres : " + ex.Message);
            }
        }


        /// <summary>
        /// Gère l'événement de clic sur le bouton "Créer Livre".
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode crée un nouveau livre avec les informations saisies par l'utilisateur.
        /// Si une erreur survient lors de la création du livre, un message d'erreur est affiché.
        /// </remarks>
        private void boutonCreateLivre(object sender, EventArgs e)
        {
            try
            {
                string titre = textBox16.Text;
                string image = textBox15.Text;
                string ISBN = textBox13.Text;
                string auteur = textBox12.Text;
                string collection = textBox2.Text;
                PublicCible publicc = comboBox9.SelectedItem as PublicCible;

                Livre.CreateLivre(0, titre, ISBN, auteur, collection, image, 0, publicc.Id);
            }
            catch (FormatException)
            {
                // En cas de format incorrect pour les champs numériques
                MessageBox.Show("Format incorrect pour les champs numériques.");
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la création du livre
                MessageBox.Show("Une erreur s'est produite lors de la création du livre : " + ex.Message);
            }
        }


        /// <summary>
        /// Gère l'événement de clic sur le bouton "Modification Livre".
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode met à jour les informations d'un livre sélectionné avec les nouvelles informations saisies par l'utilisateur.
        /// Si une erreur survient lors de la mise à jour du livre, un message d'erreur est affiché.
        /// </remarks>
        private void boutonModificationLivre(object sender, EventArgs e)
        {
            try
            {
                Livre livre = comboBox10.SelectedItem as Livre;
                string ISBN = textBox19.Text;
                string auteur = textBox18.Text;
                string collection = textBox17.Text;

                Livre.UpdateLivre(livre, ISBN, auteur, collection);
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la mise à jour du livre
                MessageBox.Show("Une erreur s'est produite lors de la modification du livre : " + ex.Message);
            }
        }


        /// <summary>
        /// Gère l'événement de clic sur le bouton "Supprimer Livre".
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode supprime un livre sélectionné de la base de données.
        /// Si une erreur survient lors de la suppression du livre, un message d'erreur est affiché.
        /// </remarks>
        private void boutonSupprLivre(object sender, EventArgs e)
        {
            try
            {
                Document document = comboBox11.SelectedItem as Document;
                Livre.DeleteLivre(document);
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la suppression du livre
                MessageBox.Show("Une erreur s'est produite lors de la suppression du livre : " + ex.Message);
            }
        }


        /// <summary>
        /// Gère le changement de sélection dans la liste déroulante des ID de livres.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode met à jour les champs d'informations du livre sélectionné dans la liste déroulante.
        /// Si aucun livre n'est sélectionné, les champs sont réinitialisés avec "Aucun".
        /// </remarks>
        private void ComboIDLivre(object sender, EventArgs e)
        {
            try
            {
                if (comboBox10.SelectedItem != null)
                {
                    Document document = comboBox10.SelectedItem as Document;
                    Livre leLivre = Livre.Get(document.Id);
                    if (leLivre != null)
                    {
                        textBox19.Text = leLivre.ISBN;
                        textBox18.Text = leLivre.Auteur;
                        textBox17.Text = leLivre.Collection;
                    }
                }
                else
                {
                    // Réinitialisation des champs si aucun livre n'est sélectionné
                    textBox19.Text = "Aucun";
                    textBox18.Text = "Aucun";
                    textBox17.Text = "Aucun";
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la récupération ou de la mise à jour des informations du livre
                MessageBox.Show("Une erreur s'est produite lors de la mise à jour des informations du livre : " + ex.Message);
            }
        }

        #endregion


        #region DVD

        //-----------------------------------------------------------
        // ONGLET "DVD"
        //-----------------------------------------------------------

        /// <summary>
        /// Gère l'événement de l'entrée dans l'onglet "DVD".
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode charge les données des DVD et des catégories publiques dans les listes déroulantes correspondantes.
        /// Si une erreur survient lors du chargement des données, un message d'erreur est affiché.
        /// </remarks>
        private void tabDvd_Enter(object sender, EventArgs e)
        {
            try
            {
                // Chargement des DVD et des catégories publiques
                lesDvd = Dvd.GetAll();
                lesCategories = PublicCible.GetAll();

                // Liaison des données aux listes déroulantes
                comboBox14.DataSource = lesDvd;
                comboBox14.DisplayMember = "id";
                comboBox13.DataSource = lesDvd;
                comboBox13.DisplayMember = "id";
                comboBox12.DataSource = lesCategories;
                comboBox12.DisplayMember = "libelle";
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors du chargement des données
                MessageBox.Show("Une erreur s'est produite lors du chargement des DVD : " + ex.Message);
            }
        }


        /// <summary>
        /// Recherche un DVD en fonction du numéro de document saisi.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode recherche un DVD dans la liste des DVD en fonction du numéro de document saisi dans le champ de texte.
        /// Si le DVD est trouvé, ses informations sont affichées dans les étiquettes correspondantes.
        /// Si aucun DVD correspondant n'est trouvé, un message d'erreur est affiché.
        /// </remarks>
        private void Recherche_DVD(object sender, EventArgs e)
        {
            try
            {
                // Réinitialisation des étiquettes d'informations
                lblnumDvd.Text = "";
                lblTitreDvd.Text = "";
                lblImageDvd.Text = "";
                lblSynopsisDvd.Text = "";
                lblRealisateurDvd.Text = "";
                lblDureeDvd.Text = "";

                // Recherche du DVD correspondant au numéro de document saisi
                bool trouve = false;
                foreach (Dvd dvd in lesDvd)
                {
                    if (dvd.Id == Convert.ToInt32(textBox1.Text))
                    {
                        // Affichage des informations du DVD trouvé
                        lblnumDvd.Text = dvd.Id.ToString();
                        lblTitreDvd.Text = dvd.Titre;
                        lblImageDvd.Text = dvd.Image;
                        lblSynopsisDvd.Text = dvd.Synopsis;
                        lblRealisateurDvd.Text = dvd.Realisateur;
                        lblDureeDvd.Text = dvd.Duree.ToString();
                        trouve = true;
                        break; // Sortie de la boucle dès qu'un DVD est trouvé
                    }
                }

                // Affichage du message d'erreur si aucun DVD correspondant n'est trouvé
                if (!trouve)
                    MessageBox.Show("Document non trouvé dans les DVD");
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la recherche du DVD
                MessageBox.Show("Une erreur s'est produite lors de la recherche du DVD : " + ex.Message);
            }
        }



        /// <summary>
        /// Événement déclenché lorsqu'un changement est détecté dans le champ de texte du titre DVD.
        /// Affiche les DVDs correspondant au titre saisi dans le DataGridView.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode parcourt la liste des DVDs et affiche ceux dont le titre correspond à la saisie effectuée
        /// dans le champ de texte du titre DVD. La recherche est insensible à la casse.
        /// </remarks>
        private void txbTitreDvd_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Effacement des données actuelles dans le DataGridView
                dgvDvd.Rows.Clear();

                // Parcours des DVDs et affichage de ceux dont le titre correspond à la saisie
                foreach (Dvd dvd in lesDvd)
                {
                    // Conversion du texte en minuscules pour une comparaison insensible à la casse
                    string saisieMinuscules = txbTitreDvd.Text.ToLower();
                    string titreMinuscules = dvd.Titre.ToLower();

                    // Si le titre du DVD contient la saisie, il est ajouté au DataGridView
                    if (titreMinuscules.Contains(saisieMinuscules))
                    {
                        dgvDvd.Rows.Add(dvd.Id, dvd.Titre, dvd.Synopsis, dvd.Realisateur, dvd.Duree);
                    }
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la recherche des DVDs
                MessageBox.Show("Une erreur s'est produite lors de la recherche des DVDs : " + ex.Message);
            }
        }


        /// <summary>
        /// Crée un nouveau DVD avec les informations saisies par l'utilisateur.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode récupère les informations saisies par l'utilisateur dans les champs de texte et les listes déroulantes
        /// pour créer un nouveau DVD dans la base de données.
        /// </remarks>
        private void boutonCreateDVD(object sender, EventArgs e)
        {
            try
            {
                // Récupération des informations saisies par l'utilisateur
                string titre = textBox20.Text;
                string image = textBox21.Text;
                string synopsis = textBox23.Text;
                string realisateur = textBox24.Text;
                int duree = Convert.ToInt32(textBox25.Text);
                PublicCible publicc = comboBox12.SelectedItem as PublicCible;

                // Création du DVD dans la base de données
                Dvd.CreateDvd(0, titre, synopsis, realisateur, duree, image, 0, publicc.Id);
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la création du DVD
                MessageBox.Show("Une erreur s'est produite lors de la création du DVD : " + ex.Message);
            }
        }


        /// <summary>
        /// Modifie les informations d'un DVD sélectionné par l'utilisateur.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode récupère les informations saisies par l'utilisateur pour modifier un DVD sélectionné.
        /// Les modifications comprennent le synopsis, le réalisateur et la durée du DVD.
        /// </remarks>
        private void boutonModificationDVD(object sender, EventArgs e)
        {
            try
            {
                // Récupération du DVD sélectionné dans la liste déroulante
                Dvd dvd = comboBox14.SelectedItem as Dvd;

                // Récupération des nouvelles informations saisies par l'utilisateur
                string synopsis = textBox26.Text;
                string realisateur = textBox27.Text;
                int duree = Convert.ToInt32(textBox28.Text);

                // Mise à jour des informations du DVD dans la base de données
                Dvd.UpdateDvd(dvd, synopsis, realisateur, duree);
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la modification du DVD
                MessageBox.Show("Une erreur s'est produite lors de la modification du DVD : " + ex.Message);
            }
        }


        /// <summary>
        /// Supprime un DVD sélectionné par l'utilisateur.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode supprime le DVD sélectionné par l'utilisateur de la base de données.
        /// </remarks>
        private void boutonSupprDVD(object sender, EventArgs e)
        {
            try
            {
                // Récupération du document (DVD) sélectionné dans la liste déroulante
                Document document = comboBox13.SelectedItem as Document;

                // Suppression du DVD de la base de données
                Dvd.DeleteDvd(document);
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la suppression du DVD
                MessageBox.Show("Une erreur s'est produite lors de la suppression du DVD : " + ex.Message);
            }
        }


        /// <summary>
        /// Met à jour les champs texte avec les informations du DVD sélectionné dans la liste déroulante.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode met à jour les champs texte avec les informations du DVD sélectionné dans la liste déroulante.
        /// Si aucun DVD n'est sélectionné, les champs texte sont réinitialisés.
        /// </remarks>
        private void ComboIDDVD(object sender, EventArgs e)
        {
            try
            {
                if (comboBox14.SelectedItem != null)
                {
                    // Récupération du document (DVD) sélectionné dans la liste déroulante
                    Document document = comboBox14.SelectedItem as Document;

                    // Récupération du DVD à partir de son ID
                    Dvd leDvd = Dvd.Get(document.Id);

                    // Mise à jour des champs texte avec les informations du DVD
                    if (leDvd != null)
                    {
                        textBox26.Text = leDvd.Synopsis;
                        textBox27.Text = leDvd.Realisateur;
                        textBox28.Text = leDvd.Duree.ToString();
                    }
                }
                else
                {
                    // Si aucun DVD n'est sélectionné, réinitialisation des champs texte
                    textBox26.Text = "Aucun";
                    textBox27.Text = "Aucun";
                    textBox28.Text = "Aucun";
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la récupération ou de la mise à jour des informations du DVD
                MessageBox.Show("Une erreur s'est produite lors de la mise à jour des informations du DVD : " + ex.Message);
            }
        }

        #endregion


        #region Exemplaires

        //-----------------------------------------------------------
        // ONGLET "CHANGEMENT ETAT SIGNALEMENT"
        //------------------------------------------------------------

        /// <summary>
        /// Événement déclenché lors de l'entrée dans l'onglet des exemplaires.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode charge les données nécessaires à l'onglet des exemplaires, telles que les catégories,
        /// les descripteurs, les livres, les états, les documents et les exemplaires. Elle affecte également les
        /// sources de données aux comboBox correspondantes pour afficher les titres de document et les libellés d'état.
        /// </remarks>
        private void tabExemplaires_Enter(object sender, EventArgs e)
        {
            try
            {
                // Chargement des catégories, des descripteurs, des livres, des états, des documents et des exemplaires
                lesCategories = PublicCible.GetAll();
                lesDescripteurs = Descripteur.GetAll();
                lesLivres = Livre.GetAll();
                lesEtats = Etat.GetAll();
                lesDocuments = Document.GetAll();
                lesExemplaires = Exemplaire.GetAll();

                // Liaison des sources de données aux comboBox correspondantes
                comboBox2.DataSource = lesDocuments;
                comboBox2.DisplayMember = "Titre";
                comboBox1.DataSource = lesEtats;
                comboBox1.DisplayMember = "Libelle";
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors du chargement des données ou de la liaison des sources de données
                MessageBox.Show("Une erreur s'est produite lors du chargement des données des exemplaires : " + ex.Message);
            }
        }


        /// <summary>
        /// Événement déclenché lors du changement de sélection du numéro de document dans la comboBox.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode récupère le document sélectionné dans la comboBox et charge les exemplaires correspondants.
        /// Elle affecte ensuite les sources de données à une autre comboBox pour afficher les numéros d'exemplaires
        /// associés au document sélectionné, puis elle affiche les détails des exemplaires dans un dataGridView.
        /// </remarks>
        private void comboSaisiNuméroDocumentChangementEtat(object sender, EventArgs e)
        {
            try
            {
                // Réinitialisation du dataGridView
                dataGridView1.Rows.Clear();

                // Récupération du document sélectionné dans la comboBox
                Document document = comboBox2.SelectedItem as Document;

                // Chargement des exemplaires correspondants au document sélectionné
                comboBox4.DataSource = Exemplaire.GetAllByDocument(document);
                comboBox4.DisplayMember = "Numero";
                lesExemplairesParDoc = Exemplaire.GetAllByDocument(document);

                // Affichage des détails des exemplaires dans le dataGridView
                foreach (Exemplaire exemplaire in lesExemplairesParDoc)
                {
                    dataGridView1.Rows.Add(exemplaire.Document.Id, exemplaire.Numero, exemplaire.DateAchat, exemplaire.Rayon.Id, exemplaire.Etat.Libelle);
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors du chargement des exemplaires ou de l'affichage des détails
                MessageBox.Show("Une erreur s'est produite lors du chargement des exemplaires : " + ex.Message);
            }
        }


        /// <summary>
        /// Événement déclenché lors du clic sur le bouton de modification d'état d'un exemplaire.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode récupère l'état sélectionné dans une comboBox, ainsi que le document et l'exemplaire sélectionnés.
        /// Elle vérifie si l'état sélectionné est différent de l'état actuel de l'exemplaire. Si c'est le cas, elle met à jour
        /// l'état de l'exemplaire dans la base de données. Ensuite, elle recharge la comboBox des numéros d'exemplaires associés
        /// au document sélectionné et met à jour les détails des exemplaires dans un dataGridView.
        /// </remarks>
        private void boutonModifEtatExemplaire(object sender, EventArgs e)
        {
            try
            {
                // Réinitialisation du dataGridView
                dataGridView1.Rows.Clear();

                // Récupération de l'état sélectionné dans la comboBox
                Etat etat = comboBox1.SelectedItem as Etat;

                // Récupération du document sélectionné dans la comboBox
                Document document = comboBox2.SelectedItem as Document;

                // Récupération de l'exemplaire sélectionné dans la comboBox
                Exemplaire exemplaire1 = comboBox4.SelectedItem as Exemplaire;

                // Vérification si l'état sélectionné est différent de l'état actuel de l'exemplaire
                if (exemplaire1.Etat.Id != etat.Id)
                {
                    // Mise à jour de l'état de l'exemplaire dans la base de données
                    DAOExemplaire.UpdateEtat(etat, document, exemplaire1);
                }

                // Rechargement de la comboBox des numéros d'exemplaires associés au document sélectionné
                comboBox4.DataSource = Exemplaire.GetAllByDocument(document);
                comboBox4.DisplayMember = "Numero";
                lesExemplairesParDoc = Exemplaire.GetAllByDocument(document);

                // Affichage des détails des exemplaires dans le dataGridView
                foreach (Exemplaire exemplaire in lesExemplairesParDoc)
                {
                    dataGridView1.Rows.Add(exemplaire.Document.Id, exemplaire.Numero, exemplaire.DateAchat, exemplaire.Rayon.Id, exemplaire.Etat.Libelle);
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la modification de l'état de l'exemplaire ou de l'affichage des détails
                MessageBox.Show("Une erreur s'est produite lors de la modification de l'état de l'exemplaire : " + ex.Message);
            }
        }


        //-----------------------------------------------------------
        // ONGLET "SIGNALEMENT"
        //------------------------------------------------------------

        /// <summary>
        /// Événement déclenché lorsque l'onglet des signalements est activé.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode est appelée lorsque l'utilisateur accède à l'onglet des signalements. Elle charge les différentes
        /// informations nécessaires à l'affichage des signalements, telles que les documents, les abonnés, et les exemplaires.
        /// Elle associe également les données chargées aux comboBox correspondantes pour permettre à l'utilisateur de
        /// sélectionner un document et un abonné pour consulter les signalements associés.
        /// </remarks>
        private void tabSignalements_Enter(object sender, EventArgs e)
        {
            try
            {
                // Chargement des différentes données nécessaires
                lesCategories = PublicCible.GetAll();
                lesDescripteurs = Descripteur.GetAll();
                lesLivres = Livre.GetAll();
                lesEtats = Etat.GetAll();
                lesDocuments = Document.GetAll();
                lesAbonnes = Abonne.GetAll();
                lesExemplaires = Exemplaire.GetAll();

                // Association des données chargées aux comboBox correspondantes
                comboBox5.DataSource = lesDocuments;
                comboBox5.DisplayMember = "Titre";
                comboBox6.DataSource = lesAbonnes;
                comboBox6.DisplayMember = "Nom";
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors du chargement des données
                MessageBox.Show("Une erreur s'est produite lors du chargement des informations pour les signalements : " + ex.Message);
            }
        }


        /// <summary>
        /// Événement déclenché lorsqu'un document est sélectionné dans la comboBox correspondante.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode est appelée lorsque l'utilisateur sélectionne un document dans la comboBox. Elle récupère les
        /// exemplaires associés à ce document et les affiche dans un dataGridView pour permettre à l'utilisateur de
        /// visualiser les détails des exemplaires.
        /// </remarks>
        private void ComboNomDocument(object sender, EventArgs e)
        {
            try
            {
                // Nettoie les données précédentes dans le dataGridView
                dataGridView1.Rows.Clear();

                // Récupère le document sélectionné dans la comboBox
                Document document = comboBox5.SelectedItem as Document;

                // Récupère les exemplaires associés à ce document
                comboBox3.DataSource = Exemplaire.GetAllByDocument(document);
                comboBox3.DisplayMember = "Numero";

                // Affiche les exemplaires dans le dataGridView
                lesExemplairesParDoc = Exemplaire.GetAllByDocument(document);
                foreach (Exemplaire exemplaire in lesExemplairesParDoc)
                {
                    dataGridView1.Rows.Add(exemplaire.Document.Id, exemplaire.Numero, exemplaire.DateAchat, exemplaire.Rayon.Id, exemplaire.Etat.Libelle);
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la récupération ou de l'affichage des exemplaires
                MessageBox.Show("Une erreur s'est produite lors du chargement des exemplaires pour ce document : " + ex.Message);
            }
        }


        /// <summary>
        /// Événement déclenché lorsqu'un utilisateur signale un problème avec un exemplaire de document.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode est appelée lorsque l'utilisateur signale un problème avec un exemplaire de document.
        /// Elle insère un signalement dans la base de données pour cet exemplaire et affiche les signalements
        /// actuels dans un dataGridView pour permettre à l'utilisateur de vérifier le signalement.
        /// </remarks>
        private void BoutonSignalement(object sender, EventArgs e)
        {
            try
            {
                // Nettoie les données précédentes dans le dataGridView
                dataGridView2.Rows.Clear();

                // Récupère l'abonné sélectionné dans la comboBox
                Abonne abonne = comboBox6.SelectedItem as Abonne;

                // Récupère le document sélectionné dans la comboBox
                Document document = comboBox5.SelectedItem as Document;

                // Récupère l'exemplaire sélectionné dans la comboBox
                Exemplaire exemplaire1 = comboBox3.SelectedItem as Exemplaire;

                // Insère un signalement dans la base de données pour cet exemplaire
                Exemplaire.InsertSignalement(document, exemplaire1, 3, abonne);

                // Met à jour l'état de l'exemplaire dans la base de données
                Exemplaire.UpdateExemplaire(document, exemplaire1, 3);

                // Récupère tous les signalements actuels
                lesSignalements = Abonne.GetAllSignalement();

                // Affiche les signalements dans le dataGridView
                foreach (Signalement signalement in lesSignalements)
                {
                    dataGridView2.Rows.Add(signalement.Document.Id, signalement.Exemplaire.Numero, signalement.Etat.Libelle, signalement.Abonne.Nom, DateTime.Now.ToString());
                }
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de la gestion du signalement
                MessageBox.Show("Une erreur s'est produite lors du signalement du problème : " + ex.Message);
            }
        }


        //-----------------------------------------------------------
        // ONGLET "CONSULTATION EXEMPLAIRE INUTILISABLE"
        //------------------------------------------------------------

        /// <summary>
        /// Événement déclenché lors de l'entrée dans l'onglet des documents inutilisables.
        /// </summary>
        /// <param name="sender">L'objet qui a déclenché l'événement.</param>
        /// <param name="e">Les données d'événement.</param>
        /// <remarks>
        /// Cette méthode est appelée lorsque l'utilisateur entre dans l'onglet des documents inutilisables.
        /// Elle récupère tous les exemplaires inutilisables dans la base de données et les affiche dans un dataGridView.
        /// Elle met également à jour les comboBox pour permettre à l'utilisateur de sélectionner un document ou un abonné
        /// pour gérer les signalements d'exemplaires inutilisables.
        /// </remarks>
        private void tabInutilisable_Enter(object sender, EventArgs e)
        {
            try
            {
                // Nettoie les données précédentes dans le dataGridView
                dataGridView3.Rows.Clear();

                // Récupère toutes les catégories de public cible
                lesCategories = PublicCible.GetAll();

                // Récupère tous les descripteurs
                lesDescripteurs = Descripteur.GetAll();

                // Récupère tous les livres
                lesLivres = Livre.GetAll();

                // Récupère tous les états
                lesEtats = Etat.GetAll();

                // Récupère tous les documents
                lesDocuments = Document.GetAll();

                // Récupère tous les abonnés
                lesAbonnes = Abonne.GetAll();

                // Récupère tous les exemplaires inutilisables
                lesExemplairesInutilisables = Exemplaire.GetAllByEtat(4);

                // Affiche les exemplaires inutilisables dans le dataGridView
                foreach (Exemplaire exemplaire in lesExemplairesInutilisables)
                {
                    dataGridView3.Rows.Add(exemplaire.Document.Id, exemplaire.Numero, exemplaire.DateAchat, exemplaire.Rayon.Id, exemplaire.Etat.Libelle);
                }

                // Met à jour la source de données pour la comboBox des documents
                comboBox5.DataSource = lesDocuments;
                comboBox5.DisplayMember = "Titre";

                // Met à jour la source de données pour la comboBox des abonnés
                comboBox6.DataSource = lesAbonnes;
                comboBox6.DisplayMember = "Nom";
            }
            catch (Exception ex)
            {
                // En cas d'erreur lors de l'entrée dans l'onglet des documents inutilisables
                MessageBox.Show("Une erreur s'est produite lors de l'entrée dans l'onglet des documents inutilisables : " + ex.Message);
            }
        }

        #endregion
    }
}

